##################################################################
## Solution to the Numpy Central Limit Theorem Homework
##################################################################


import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

## generate a single sample from the normal distribution
samp1 = np.random.normal(0,1,10)
## calculate the mean
np.mean(samp1)
## Use list comprehension to do this multiple times
norm_sample_means = np.array([np.mean(np.random.normal(0,1,10)) for i in range(100)])
## plot resulting means
plt.hist(norm_sample_means)
sns.distplot(norm_sample_means)
## 1a)
norm_sample_means = np.array([np.mean(np.random.normal(0,1,10)) for i in range(100)])
norm_sample_means.shape
## plot resulting means
plt.hist(norm_sample_means)
## 1b)
plt.hist(np.random.poisson(10,10))
poisson_sample_means = np.array([np.mean(np.random.poisson(10,10)) for i in range(100)])
poisson_sample_means.shape
## plot resulting means
plt.hist(poisson_sample_means)
## 1c)
plt.hist(np.random.uniform(0,10,10))
uniform_sample_means = np.array([np.mean(np.random.uniform(1,10,10)) for i in range(100)])
uniform_sample_means.shape
## plot resulting means
plt.hist(uniform_sample_means )

## 2a)
plt.hist(np.random.normal(0,1,100))
norm_sample_means = np.array([np.mean(np.random.normal(0,1,100)) for i in range(100)])
norm_sample_means.shape
## plot resulting means
plt.hist(norm_sample_means)
## 2b)
plt.hist(np.random.poisson(10,100))
poisson_sample_means = np.array([np.mean(np.random.poisson(10,100)) for i in range(100)])
poisson_sample_means.shape
## plot resulting means
plt.hist(poisson_sample_means)
## 2c)
plt.hist(np.random.uniform(0,10,100))
uniform_sample_means = np.array([np.mean(np.random.uniform(1,10,100)) for i in range(100)])
uniform_sample_means.shape
## plot resulting means
plt.hist(uniform_sample_means )

## 3a)
plt.hist(np.random.normal(0,1,1000))
norm_sample_means = np.array([np.mean(np.random.normal(0,1,1000)) for i in range(100)])
norm_sample_means.shape
## plot resulting means
plt.hist(norm_sample_means)
## 3b)
plt.hist(np.random.poisson(10,1000))
poisson_sample_means = np.array([np.mean(np.random.poisson(10,1000)) for i in range(100)])
poisson_sample_means.shape
## plot resulting means
plt.hist(poisson_sample_means)
## 3c)
plt.hist(np.random.uniform(0,10,1000))
uniform_sample_means = np.array([np.mean(np.random.uniform(1,10,1000)) for i in range(100)])
uniform_sample_means.shape
## plot resulting means
plt.hist(uniform_sample_means )



