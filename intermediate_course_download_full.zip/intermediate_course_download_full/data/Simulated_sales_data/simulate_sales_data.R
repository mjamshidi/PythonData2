###########################################################
## Simulate Binary Outcome Data
##  Author: Evan Carey
##  Date Created: 2015-04-24
###########################################################
set.seed(16)
## Simulate sales data
## parms
n_pats <- 10000
n_clust <- 50
## simulate variables
customer_id <- 100000:(100000+n_pats-1)
clust_id <- factor(sample(n_clust,n_pats,replace = T))
gender <- factor(sample(c("Male","Female"),
                        n_pats,replace = T,
                        prob = c(0.6,0.4)))
age <- round(rnorm(n_pats,
                   65 - 10*ifelse(gender=='Male',1,0),
                   10))
marketing_exposure <- rpois(n_pats,
                            6 - 3*ifelse(gender=='Male',0,1))
activity <- factor(sample(c("Low","Med","High"),
                     n_pats,replace = T,
                     prob = c(0.35,0.45,.2)))
income <- round(rnorm(n_pats,65,10))
num_accounts <-  rpois(n_pats,0.5)
current_customer <- factor(sample(c("Yes","No"),
                                  n_pats,replace = T,
                                  prob = c(0.3,0.7)))
x1 <- rnorm(n_pats,50,10)
x2 <- rnorm(n_pats,10,2)
x3 <- rnorm(n_pats,100,20)
x4 <- rpois(n_pats,10)
x5 <- rpois(n_pats,2)
beta_sale <- 
  (.5 
  + .2*scale(age) 
  #- .25*ifelse(gender=="Male",1,0) 
  + .07*marketing_exposure**0.3 * ifelse(gender=="Female",1,0)
  + .3*ifelse(activity=="High",1,0) 
  - .5*ifelse(activity=="Low",1,0) 
  + .25*ifelse(current_customer=="Yes",1,0) 
  + .3*scale(x3)
  - .03*scale(x4)**2
  + rnorm(n_clust,0,.4)[clust_id])
logit_trans <- function(x) exp(x)/(1+exp(x))
prob_sale <- logit_trans(beta_sale)
summary(prob_sale)
sale <- factor(ifelse(rbinom(n_pats,1,prob_sale) == 0, "No","Yes"))
summary(sale)
## Establish amount of sale
beta_amount <- 
  (2
   + 1*scale(age)**2
   #+ 1*ifelse(gender=="Male",1,0) 
   + 2*marketing_exposure**0.3 * ifelse(gender=="Female",1,0)
   + .3*scale(x1)
   - .03*scale(x2)**2
   + rnorm(n_clust,0,1)[clust_id])
sale_amount <- (rgamma(n_pats,abs(beta_amount))+0.1) * ifelse(sale=='Yes',1,0) * 100
hist(sale_amount)
customers <- 
  data.frame(customer_id,sale,sale_amount,region=clust_id,age,gender,activity,
             marketing_exposure,x1,x2,x3,x4,x5,num_accounts,current_customer,income)
## split into two datasets
ind <- sample(nrow(customers),.2*nrow(customers))
write.csv(customers[-ind,],
          file="J:/Sync/data_files/Simulated_sales_data_2/customer_sales1.csv",
          row.names=F)
write.csv(customers[ind,],
          file="J:/Sync/data_files/Simulated_sales_data_2/customer_sales2.csv",
          row.names=F)
## Test interaction term
summary(lm(sale_amount ~ age + I(marketing_exposure**0.3)*gender,
    data=subset(customers,sale_amount > 0)))
summary(lm(sale_amount ~ age + I(marketing_exposure**0.3)*gender + x1 + x2 + I(age**2) + activity,
           data=subset(customers,sale_amount > 0)))

## Test predictive value of model
library(caret)
mod_glm <- train(sale~age+marketing_exposure+gender+x1+x2+x3+x4+x5,
                 data=customers,
                 method = "rf")
## Calculate Final Performance Statistics
confusionMatrix(data = predict(mod_glm,customers,type='raw'),
                reference=customers$sale)
