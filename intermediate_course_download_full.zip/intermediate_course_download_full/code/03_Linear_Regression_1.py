
# coding: utf-8

# # Linear Regression 1

# *Author: Evan Carey*
# 
# *Copyright 2017, BH Analytics, LLC*

# ## Overview
# 
# The purpose of this lecture is to go over linear regression, which is the foundation of modern frequentist statistics. We will examine linear regression with a single and multiple predictors, as well as basic non-linear functions. We will consider the assumptions of linear regression, and map that to the actual statistical model we are fitting. 

# ## Libraries

# In[1]:

## Import Modules
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns


# In[2]:

## Enable inline plotting for graphics
get_ipython().magic('matplotlib inline')


# In[3]:

## Get Version information
print(sys.version)
print("Pandas version: {0}".format(pd.__version__))
print("Matplotlib version: {0}".format(matplotlib.__version__))
print("Numpy version: {0}".format(np.__version__))
print("Statsmodels version: {0}".format(statsmodels.__version__))


# ## Check your working directory

# Subsequent sessions may require you to identify and update your working directory so paths correctly point at the downloaded data files. You can check your working directory like so:

# In[4]:

## Check/set your working directory
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"C:\Users\evan\Dropbox\BH_Katie_Share\Goldman_Sachs")
print("My new working directory:\n" + os.getcwd())


# ## Linear Regression

# * Heart of modern frequentist statistics
# * Explore relationships between predictors and an outcome
# * Many different types of regression
# * Some examples of regression you currently use
# * What type of data?
# * What size of data?
# * What are your outputs?
# * Regression

# ## Different Types of Regression

# There are many different types of regression (listed below). All of the lessons we learn in basic linear regression will apply to the other forms of general linear regression, as well as other multivariate parametric modelling strategies. 
# 
# * OLS Regression, or simple linear regression
# * Multiple Linear Regression
# * Logistic Regression
# * Cox Time to Event Analysis
# * Mixed Effects (or hierarchical)
# * Repeated Measures (time series)
# * Non-parametric

# ## General Regression Strategy

# * Collect appropriate data
# * Identify Outcomes / predictors
# * Investigate "shape" of data
# * Consider appropriate functional form
# * Apply prior knowledge
# * Select "best" model and variables
# * Check model for validity (residuals, etc)
# * Apply model
# * Predict new results

# ## OLS Regression

# * "Basic" regression
# * Easy to learn conceptually, applies to other situations
# * Outcome is a continuous variable
# * Predicting weight
# * Predicting monetary values
# * Predicting Lab tests

# ## Linear Regression Assumptions

# * Assumptions: this is key
# * Normality
# * Independence
# * Linearity
# * Homoscedasticity (pull this off in scrabble)
# * What's all this about assumptions. . . If I get numbers out it worked. . .

# ## Example of Regression: Predicting Miles per Gallon

# We will learn about regression in the context of a simple example of making inference on miles per gallon in a dataset of cars. This is a classic dataset that has been used in other tutorials, you may recognize it. 
# 
# We will begin by importing the dataset with pandas.

# In[5]:

mtcars = pd.read_csv(r'C:\Users\evan\Dropbox\BH_Katie_Share\Goldman_Sachs\data\mtcars.csv')
mtcars.head()


# The variable we are interested in predicting is 'mpg' (miles per gallon). This is the fuel efficiency of the vehicle. We will be predicting the mean mpg.
# 
# We start off by creating a simple null model. In the absence of any other other information, what is our best estimate of the mean mpg for this dataset? 
# 
# It is simply the sample mean. 

# In[6]:

mtcars.mpg.mean()


# Another relevant parameter is the spread of the data. This is approximated by calculating the sample standard deviation

# In[7]:

mtcars.mpg.std()


# We can also visually examine the distribution of this data. 

# In[8]:

sns.distplot(mtcars.mpg)


# ## First Linear Model: Null model

# There is a direct paralell to what we just did in linear modelling. We can fit the intercept only model, or the "null" model and we will estimate the sample mean. 
# 
# Here is the actual model we are fitting:
# 
# $$ mean(mpg)=\beta_0 + e$$
# 
# $$ \overline{mpg}=\beta_0 + e$$
# 
# Where $e$ is the error term that is normally distributed with mean=0 and variance = $\sigma^2$

# In[9]:

mod0 = smf.ols('mpg ~ 1', data=mtcars).fit()
mod0.summary()


# ## Model: Single predictor

# Our second model will include a single categorical predictor. In this case we will use am (type of transmission) as a predictor and see if mpg depends on transmission. We could start by doing this using grouped analysis with pandas:

# In[10]:

mtcars.groupby('am').mpg.mean()


# In[11]:

mtcars.groupby('am').mpg.plot(kind='kde')


# There seems to be a difference in MPG for the different type of transmissions. We can fit a linear model that includes this as a predictor to get a statistical test. The model we are fitting looks like this:
# 
# $$ \overline{mpg}=\beta_0 + \beta_{am}*(am) + e$$
# 

# The intercept is implied in this model, so we do not need to include the + 1. 

# In[12]:

mod1 = smf.ols('mpg ~ 1 + C(am)', data=mtcars).fit()
mod1.summary()


# Can you look at the parameter estimate, and figure out what the coefficients mean?
# 
# Here is the model equation with the parameter estimates:
# 
# $$ \overline{mpg}=17.1 + 7.2*(am) + e$$

# There seems to be a difference by transmission type. However, is this difference statisticallye significant? What null hypothesis is the p-value associated with this parameter testing? 
# 
# If there were no difference, then $\beta_{am}$ would be equal to 0. So the null hypothesis is:
# 
# $\beta_{am} = 0$ 
# 
# The p-value is quite small, so we reject this null hypothesis as unlikely given the data, and conclude that $\beta_{am}$ is not equal to 0. 

# ## Model: Categorical predictor with more than 2 levels

# What is our categorical predictor has more than two levels? Cylinder has 3 possible values in this dataset. We may wish to understand how mean MPG varies by the number of cylinders in the car. Here are some non-modelling approached to doing this:

# In[13]:

mtcars.groupby('cyl').mpg.mean()


# In[14]:

mtcars.groupby('cyl').mpg.plot(kind='kde')


# It looks like cylinder is associated with mpg in this data. Let's fit a regression model to further investigate this relationship. Here is our new model equation:
# 
# $$ \overline{mpg}=\beta_0 + \beta_{cyl6}*(cyl==6) + \beta_{cyl8}*(cyl==8) + e$$
# 
# 
# Why did I not include a term for cyl==4? 
# 
# Because it is absorbed into the intercept. 
# 
# Here is the code to actually fit the model:

# In[15]:

mod2 = smf.ols('mpg ~ C(cyl)', data=mtcars).fit()
mod2.summary()


# Here is the model with the parameters:
# 
# $$ \overline{mpg}=26.7 - 6.9*(cyl==6) - 11.6*(cyl==8) $$
# 
# What is the expected value of mpg for a 6 cylinder car with this model?
# 
# $$ \overline{mpg}=26.7 - 6.9*(1) - 11.6*(0) $$

# In[16]:

26.7 - 6.9*1 - 11.6*0


# What if I did not include the C() in my model formula? In that case, I would be treating cylinder as a numeric variable. 

# In[17]:

mod3 = smf.ols('mpg ~ cyl', data=mtcars).fit()
mod3.summary()


# What is the model that I just fit?
# 
# $$ \overline{mpg}=\beta_0 + \beta_{cyl}*(cyl) + e$$
# 
# That is an odd model. What is my prediction of mpg for a 4 cylinder car?
# 
# $$ \overline{mpg}=37.9 - 2.87*(4)$$

# In[18]:

37.9 - 2.87*(4)


# And here is a visual of the model we just fit:

# In[19]:

sns.regplot('cyl','mpg',
            data=mtcars,
           ci=None)


# It actually doesn't look unreasonable here, but note it is not the same model as the categorical version!
# 
# We fit the variable as a continuous predictor. Let's investigate that further...

# ## Model: Continuous Predictor

# What about using a continuous predictor in the equation? This is similar to doing a correlation, but not exactly. Let's assume there is a linear relationship between mpg and disp (size of the engine). Here is a figure demonstrating that relationship:

# In[20]:

sns.regplot('disp','mpg',
            data=mtcars,
           ci=None)


# This looks like a reasonable fit, althought we will look at a non-linear fit next. The regression model we will fit for this data looks like this:
# 
# $$ \overline{mpg}=\beta_0 + \beta_{disp}*(disp) + e$$
# 
# We are assuming a linear trend of disp on mpg with this model. We can fit is easily like so:

# In[21]:

mod3 = smf.ols('mpg ~ disp', data=mtcars).fit()
mod3.summary()


# Here is the model with the estimated parameters:
# 
# $$ \overline{mpg}=29.6 - 0.0412*(disp)$$
# 
# The average displacement among all cars is:

# In[22]:

mtcars.disp.mean()


# So for a car with displacement = 200, our predicted mpg would be:
# 
# $$ \overline{mpg}=29.6 - 0.0412*(200)$$

# In[23]:

29.6 - 0.0412*(200)


# And for a car with displacement = 250, our predicted mpg would be:
# 
# $$ \overline{mpg}=29.6 - 0.0412*(250)$$

# In[24]:

29.6 - 0.0412*(250)


# ## Model: Polynomial regression

# It looks like the assumption of linearity may be untrue for displacement. Perhaps a non-linear function would provide a better fit of the data? 
# 
# Here is a visual of a polynomial regression option:

# In[25]:

sns.regplot('disp','mpg',
            data=mtcars,
           ci=None,
           order=2)


# We can fit this model by specifying an $x^2$ term in the model. 
# 
# $$ \overline{mpg}=\beta_{int} + \beta_{disp}*(disp) + \beta_{disp2}*(disp^2) + e$$
# 
# We use the I() wrapper to ask for an actual mathematical evaluation of the term. 

# In[26]:

mod4 = smf.ols('mpg ~ disp + I(disp**2)', data=mtcars).fit()
mod4.summary()


# The p-value for the higher level squared term indicates this is a good fit, so we can leave it in. 

# ## Model: Multiple parameters

# We can include both categorical and continuous predictors in our model. Can you interpret the following model fit and output? 
# 
# $$ \overline{mpg}=\beta_{int} + \beta_{cyl6}*(cyl==6) + \beta_{cyl8}*(cyl==8) + \beta_{disp}*(disp) + \beta_{disp2}*(disp^2) + \beta_{am}*(am==1) + e$$

# In[27]:

mod5 = smf.ols('mpg ~ C(cyl) + disp + I(disp**2) + C(am)', data=mtcars).fit()
mod5.summary()


# It looks like am is no longer predictive in this model after we put the other variables in the model. Let's remove it and look at the model again. 

# In[28]:

mod6 = smf.ols('mpg ~ C(cyl) + disp + I(disp**2)', data=mtcars).fit()
mod6.summary()


# The squared term for displacement is now questionable as well. Perhaps cylinder helps to overcome some of the non-linearity, or we just don't have enough data points here to support the more complex model. Let's remove it for now.

# In[29]:

mod7 = smf.ols('mpg ~ C(cyl) + disp', data=mtcars).fit()
mod7.summary()


# This will be our final model for this exercise. We are done model building, let's use this model to do some predictions. 

# ## Making predictions from a model

# We can use a model object to 'score' a new dataset, or make predictions for each row. In this case we are going to try to predict the mean mpg for another sample of data. Let's just take the first 6 rows of the dataframe and score it as an example case. 

# In[30]:

mtcars_new = mtcars.head(6).copy()


# In[31]:

mtcars_new


# In[32]:

mtcars_new['pred_mpg'] = mod7.predict(mtcars_new)


# In[33]:

mtcars_new


# In[34]:

sns.jointplot('pred_mpg', 'mpg', data=mtcars_new)


# ## Linear Regression Assumptions

# * Assumptions: this is key
# * Normality
# * Independence
# * Linearity
# * Homoscedasticity (pull this off in scrabble)
# * What's all this about assumptions. . . If I get numbers out it worked. . .

# ## Homoscedasticity

# This is the assumption of constant variance. This can be violated, especially when we have a wide range of data. Here is a simulated example so you can see the issue:

# In[35]:

df_spread = pd.read_csv(r'data\hetero_out.csv')


# In[36]:

plt.scatter(df_spread.x,df_spread.out2,alpha=0.3)


# Sometimes we may use the log function to 'stabalize' the variance. This is commonly suggested, but you must be careful of the interpretation of your results after this...(more on this in subsequent lectures). 

# In[37]:

plt.scatter(df_spread.x,np.log(df_spread.out2),alpha=0.3)


# In this outcome, there is an issue with both non-constant variance and linearity:

# In[38]:

plt.scatter(df_spread.x,df_spread.out3,alpha=0.3)


# In[39]:

plt.scatter(df_spread.x,np.log(df_spread.out3),alpha=0.3)

