########################################################################
## Title: Solution to Sale Exercise
## Author: Evan Carey, written for BH Analytics, LLC
## Date Created: 2017-04-19
########################################################################

## import modules
## Import Modules
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
from sklearn.metrics import confusion_matrix
import sklearn
from sklearn import datasets
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns

## Get Version information
print(sys.version)
print("Pandas version: {0}".format(pd.__version__))
print("Matplotlib version: {0}".format(matplotlib.__version__))
print("Numpy version: {0}".format(np.__version__))
print("Seaborn version: {0}".format(sns.__version__))

# Working Directory
import os
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"C:\Users\evan\Dropbox\BH_Katie_Share\Goldman_Sachs")
print("My new working directory:\n" + os.getcwd())

## import data
sale_df = pd.read_csv(r'data\Simulated_sales_data\customer_sales1.csv')

## Examine Data
sale_df.head()
sale_df.tail()
sale_df.describe()

## Look at outcome
sns.distplot(sale_df.sale_amount)

## Mean Sale Amount
sale_df.sale_amount.mean()

## Look at overall correlations with the outcome:
res1 = sale_df.corr()
res1.loc['sale_amount',:]

## Create formula for all variables in model
vars_remove = ['sale_amount','customer_id','sale']
vars_left = set(sale_df.columns) - set(vars_remove)
formula = "sale_amount ~ " + " + ".join(vars_left)
formula

## use Patsy to create model matrices
Y,X = dmatrices(formula,
                sale_df)

## Split Data into training and sample
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,
                                                    Y,
                                                    test_size=0.25,
                                                    random_state=42)

##### Fit Models ####

#### Fit Linear Model
## import linear model
from sklearn import linear_model
## Define model parameters
clf = linear_model.LinearRegression(fit_intercept=False)
## fit model using data with .fit
clf.fit(X_train,y_train)
## Create dict to store all these results:
result_scores = {}
## Score the Model on Training and Testing Set
result_scores['OLS'] = \
            (clf.score(X_train,y_train),
             clf.score(X_test,y_test))
## Create Function to Print Results
def get_results(x1):
    print("\n{0:8}   {1:4}    {2:4}".format('Model','Train','Test'))
    print('--------------------------------')
    for i in x1.keys():
        print("{0:8}   {1:.4}   {2:.4}".format(i,x1[i][0],x1[i][1]))
get_results(result_scores)

## Fit LASSO Model with pipeline standardization
## Select the alpha through cross validation (leave one out)
from sklearn import preprocessing
from sklearn.pipeline import Pipeline
clf = linear_model.LassoCV(alphas=[0.01, 0.05, 0.1, 0.15, 0.2, 0.5,0.7,1])
scaler = preprocessing.StandardScaler()
pipe1 = Pipeline([("scale", scaler),
                  ("lasso", clf)])
pipe1.fit(X_train,y_train)
# Check alpha
pipe1.named_steps['lasso'].alpha_
## Score the Model on Training and Testing Set
result_scores['LASSO'] = \
            (pipe1.score(X_train,y_train),
             pipe1.score(X_test,y_test))
get_results(result_scores)

## Fit Ridge Model with pipeline standardization
## Select the alpha through cross validation (leave one out)
from sklearn import preprocessing
from sklearn.pipeline import Pipeline
clf = linear_model.RidgeCV(alphas=[0.01, 0.05, 0.1, 0.15, 0.2, 0.5])
scaler = preprocessing.StandardScaler()
pipe2 = Pipeline([("scale", scaler),
                  ("ridge", clf)])
pipe2.fit(X_train,y_train)
## Score the Model on Training and Testing Set
result_scores['Ridge'] = \
            (pipe2.score(X_train,y_train),
             pipe2.score(X_test,y_test))
get_results(result_scores)

## Fit LASSO Model with pipeline standardization and all polynomials
## Select the alpha through cross validation (leave one out)
from sklearn import preprocessing
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures
clf = linear_model.LassoCV(alphas=[0.01, 0.05, 0.1, 0.15, 0.2, 0.5,0.7,1])
scaler = preprocessing.StandardScaler()
poly_feat = PolynomialFeatures(degree=2,include_bias=False)
pipe3 = Pipeline([("scale", scaler),
                  ("poly", poly_feat),
                  ("lasso", clf)])
pipe3.fit(X_train,np.ravel(y_train))
## Find the alpha fit here
pipe3.named_steps['lasso'].alpha_
## Score the Model on Training and Testing Set
result_scores['LASSO_Poly'] = \
            (pipe3.score(X_train,y_train),
             pipe3.score(X_test,y_test))
get_results(result_scores)

## Import the second data set
sale2_df = pd.read_csv(r'data\Simulated_sales_data\customer_sales2.csv')
## use Patsy to create model matrices
Y,X = dmatrices(formula,
                sale2_df)
## Score the second dataset
pipe3.score(X,Y)
## Create predictions and save them
sale2_df['predicted_sale_amount'] = pipe3.predict(X)

## Examine the correlation
sns.jointplot(sale2_df.predicted_sale_amount,
              sale2_df.sale_amount)

## Export the dataset to excel
# sale2_df.to_excel()

