
# coding: utf-8

# # Inferential Statistics

# *Author: Evan Carey*
# 
# *Copyright 2017, BH Analytics, LLC*

# ## Overview
# 
# The purpose of this section is to demonstrate how to implement inferential statistics in Python. We will cover both continuous and discrete case variables.

# ## Libraries

# In[1]:

## Import Modules
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
from sklearn.metrics import confusion_matrix
import sklearn
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels


# In[2]:

## Enable inline plotting for graphics
get_ipython().magic('matplotlib inline')


# In[3]:

## Get Version information
print(sys.version)
print("Pandas version: {0}".format(pd.__version__))
print("Matplotlib version: {0}".format(matplotlib.__version__))
print("Numpy version: {0}".format(np.__version__))
print("SciKitLearn version: {0}".format(sklearn.__version__))
print("Statsmodels version: {0}".format(statsmodels.__version__))


# ## Check your working directory

# Subsequent sessions may require you to identify and update your working directory so paths correctly point at the downloaded data files. You can check your working directory like so:

# In[4]:

## Check/set your working directory
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"C:\Users\evan\Dropbox\BH_Katie_Share\Goldman_Sachs")
print("My new working directory:\n" + os.getcwd())


# ## Import the dataset

# You should already have some experience with Pandas if you are taking this course. Below, I use Pandas to import a CSV file that we will use for a few examples. This is a dataset of low birthweights and various risk factors. 

# In[5]:

#### Binary Outcomes
birthwt = pd.read_csv(r"data\birthwt.csv")
birthwt["low_cat"] = pd.Categorical.from_codes(birthwt.low,categories=["No","Yes"])
birthwt["smoke_cat"] = pd.Categorical.from_codes(birthwt.smoke,categories=["No","Yes"])
birthwt["race_cat"] = birthwt["race"].astype('category')


# In[6]:

birthwt.head()


# In[7]:

birthwt.tail()


# ## Describing Categories

# The heart of categorical data analysis is frequency tables. How often do the levels of the values occur?
# 
# The value_counts() method accomplishes this in 1D

# In[8]:

pd.concat([birthwt.low_cat.value_counts(),
          birthwt.low_cat.value_counts(normalize=True)], axis=1)


# ## 2D Freq Tables

# Frequency tables using 2+ dimensions leverage the pd.crosstab() function.
# 
# You can normalize the tables and add margins. 

# In[9]:

## Make 2d+ frequency tables
pd.crosstab(birthwt.smoke_cat,birthwt.low_cat)


# In[10]:

pd.crosstab(birthwt.smoke_cat,
            birthwt.low_cat,
           margins=True)


# In[11]:

pd.crosstab(birthwt.smoke_cat,birthwt.low_cat,
            normalize=0)


# ## Chi-Square Test

# We use a Chi-Square test to formally check for independence amongst this 2x2 table. 
# 
# We use the scipy package for this.

# In[12]:

## Chisquared test / Categorical Data Analysis
from scipy.stats import chi2_contingency

tbl1  = pd.crosstab(birthwt.smoke_cat,birthwt.low_cat)
chi2, p, ddof, expected = chi2_contingency(tbl1)
msg = "Test Statistic: {}\np-value: {}\nDegrees of Freedom: {}\n"
print(msg.format(chi2, p, ddof))


# ## Fisher Exact Test

# If there is a small cell value, we must use the Fisher exact instead of the chi-square.

# In[13]:

## Chisquared test / Categorical Data Analysis
from scipy.stats import fisher_exact

tbl1  = pd.crosstab(birthwt.smoke_cat,birthwt.low_cat)
oddsratio,p = fisher_exact(tbl1)
msg = "p-value: {}"
print(msg.format(p))


# ## Continuous Distributions

# We will import a small file of traits of cars to examine statistical methods of inference for continuous variables. 
# 

# In[14]:

mtcars = pd.read_csv(r"data\mtcars.csv")
mtcars.head()


# ## Focus on Miles per Gallon

# How do we examine a continuous distribution? 
# What might our 'target of inference' be here?

# In[15]:

mtcars.describe()


# In[16]:

import seaborn as sns
sns.distplot(mtcars.mpg)


# In[17]:

mtcars.mpg.mean()


# In[18]:

mtcars.mpg.median()


# In[19]:

mtcars.mpg.std()


# In[20]:

mtcars.mpg.var()


# ## Comparing Distributions

# * If we ask the question, do miles per gallon differ by transmission, what do we mean statistically by this? 
#   
#   
# * To start answering this question, how would you describe the distribution of mpgs, independent of trans? (hint below)
# 

# In[21]:

mtcars.mpg.mean()


# When we compare two distributions, we are really comparing the sample average distributions..
#   
# Then, what does it mean to conclude two distributions are different?
#   
# That means we believe their underlying population means are different!
#   
# “Sure they are different, but are they statistically significantly different? “
# 

# ## Comparing Two Distributions

# We can visually compare the two different distributions of data.
#   
# We might start to ask ourselves if they look that different…
#   
# Remember, the bigger the difference OR the more observations I have, the more certain I am of the result…

# In[22]:

## Compare MPGs across groups
sns.boxplot(x="am", y="mpg",data=mtcars)


# In[23]:

mtcars_group = mtcars.groupby(["am"])
mtcars_group.mpg.mean()


# In[24]:

mtcars_group.mpg.hist()


# In[25]:

mtcars_group.mpg.plot(kind="kde",legend=True)


# In[26]:

mtcars_group.mpg.agg([np.mean,np.std])


# ## T-tests for statistical comparison

# We use a t-test to do this comparison formally. 
#   
# What information do we need to know for the t-test?
#   
# Sample size, sample means, sample variance.
# 

# In[27]:

## Perform t-test
test_stat, p, df =     sm.stats.ttest_ind(mtcars.mpg[mtcars.am==0],
                       mtcars.mpg[mtcars.am==1])
msg = "Test Statistic: {}\nDegrees of Freedom: {}\np-value: {}\n"
print(msg.format(test_stat, df, p))


# In[28]:

test_stat, p, df =     sm.stats.ttest_ind(mtcars.mpg[mtcars.am==0],
                       mtcars.mpg[mtcars.am==1],
                       usevar="unequal")
msg = "Test Statistic: {}\nDegrees of Freedom: {}\np-value: {}\n"
print(msg.format(test_stat, df, p))


# ## Assumptions about Normality

# The reason we can use this test is because we assume the sample mean is distributed normally. It is important to note that we do not make any assumptions about the actual data distribution here, we are only making assumptions about the distribution of the sample mean(s)!
#   
# We can do this because of something called the central limit theorum. 
#   
# This theorem says that no matter what the underlying distribution of some values are, if we take a sample and then calculate the sample average, the distribution of those sample averages will be normal if we have enough sample size (generally 40 or more).
#   
# How do we estimate the underlying population mean?
#   
# We calculate the sample average and the sample variance!

# ## Non-parametric group comparisons

# If we are unable to assume normality, or if we are interested in making inference on something other than the mean, we may decide to use a non-parametric method to do the sample comparison.
# 
# One option would be the Kruskal-Wallis test, which is a test of population medians. 

# In[29]:

from scipy.stats.mstats import kruskalwallis
test_stat, p =     kruskalwallis(mtcars.mpg[mtcars.am==0],
                  mtcars.mpg[mtcars.am==1])
msg = "Test Statistic: {}\np-value: {}\n"
print(msg.format(test_stat, p))


# ## What about more than two?

# What happens if there are more than two groups?
# 
# We now are asking the question, are these population means unequal? 
# 
# Is at least one of the group means not equal to the others?

# ## Visually Explore The Distributions

# Does MPG differ by number of cylinders?

# In[30]:

## mpg across cylinders
mtcars.boxplot("mpg",by="cyl")


# In[31]:

mtcars_group = mtcars.groupby(["cyl"])
mtcars_group.mpg.plot(kind="kde",legend=True)


# In[32]:

mtcars_group.mpg.agg([np.mean,np.std])


# ## ANOVA

# The formal statistical test for this comparison is an ANOVA. This is an extension of a t-test. 

# In[33]:

## perform anova
mtcars_lm1=smf.ols('mpg~C(cyl)', data=mtcars) #Specify C for Categorical
sm.stats.anova_lm(mtcars_lm1.fit(), typ=2)


# In[34]:

## get f statistic and p-value
sm.stats.anova_lm(mtcars_lm1.fit(), typ=2).ix[0,2:4]


# ## Correlation

# If we are interested in assessing the relationship between two continuous variables, we can use different forms of correlation. 
# 
# We typically summarize continuous by continuous relationships as correlation. 
# 
# Simply put, do these variables move together? Is there a relationship between them? 
# 

# In[35]:

## Correlation
## seaborn image 
sns.jointplot(x="mpg", y="disp", data=mtcars, kind="reg")


# In[36]:

sns.jointplot(x="mpg", y="hp", data=mtcars, kind="reg")


# ## Calculating Correlation

# We can calculate correlation as shown below.
# 
# Do you know the difference between Spearman and Pearson (the default)?
# 
# Pearson is the linear correlation, Spearman evaluates the monotonic relationship of the ranks.
# 
# We can use pandas to get a matrix of correlation values, however, we do not get the p-values. 

# In[37]:

## Examine the linear correlation between mpg and other values
mtcars.loc[:,["mpg","disp","hp"]].corr()


# In[38]:

mtcars.loc[:,["mpg","disp","hp"]].corr(method="spearman")


# To get the p-values, we must use some other function. We can use scipy to do so. 

# In[39]:

from scipy.stats import pearsonr
r, p =     pearsonr(mtcars.mpg,
             mtcars.disp)
msg = "Correlation: {}\np-value: {}\n"
print(msg.format(r, p))


# We can also get the spearman coefficient here.

# In[40]:

from scipy.stats import spearmanr
r, p =     spearmanr(mtcars.mpg,
             mtcars.disp)
msg = "Correlation: {}\np-value: {}\n"
print(msg.format(r, p))

