########################################################################
## Title: Solution to Sale Exercise
## Author: Evan Carey, written for BH Analytics, LLC
## Date Created: 2017-04-19
########################################################################

## import modules
import pandas as pd 
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns
import os
import sys

## Get Version information
print(sys.version)
print("Pandas version: {0}".format(pd.__version__))
print("Matplotlib version: {0}".format(matplotlib.__version__))
print("Numpy version: {0}".format(np.__version__))
print("Seaborn version: {0}".format(sns.__version__))

# Working Directory
import os
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"J:\Sync\Work\BHAnalytics\Python")
print("My new working directory:\n" + os.getcwd())

## import data
sale_df = pd.read_csv(r'data\Simulated_sales_data\customer_sales1.csv')
sns.distplot(sale_df.sale_amount)
## Subset down to only the rows with sales
sub_sale_df = sale_df.loc[sale_df.sale_amount>0,].copy()
sns.distplot(sub_sale_df.sale_amount)
## Examine Data
sub_sale_df.head()
sub_sale_df.tail()
sub_sale_df.describe()

## Look at outcome
sns.distplot(sub_sale_df.sale_amount)

## Look at overall correlations with the outcome:
res1 = sub_sale_df.corr()
res1.loc['sale_amount',:]

## Look at relationship between cont and categorical

## Look at potential non-linear fits
sns.regplot(x='age',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})
sns.regplot(x='marketing_exposure',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})
sns.regplot(x='x1',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})
sns.regplot(x='x2',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})
sns.regplot(x='x3',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})
sns.regplot(x='x4',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})
sns.regplot(x='x5',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})

## Fit age, marketing exposure, and gender interaction into the model
mod5 = smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=2) + gender + age + I(age**2)',
               data=sub_sale_df).fit()
print(mod5.summary())
## Add gender interaction with marketing exposure 
mod6 = smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=2) * gender + age + I(age**2)',
               data=sub_sale_df).fit()
print(mod6.summary())
## Compare models
mod6.aic
mod5.aic
## By AIC, we keep mod6. 
## What about other variables?
mod7 = smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=2) * gender + age + I(age**2) + x1 + x2 + x3 + x4 + x5',
               data=sub_sale_df).fit()
print(mod7.summary())
## Let's only keep x1
mod8 = smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=2) * gender + age + I(age**2) + x1',
               data=sub_sale_df).fit()
print(mod8.summary())
## What about the other variables?
mod9 = smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=2) * gender + age + I(age**2) + x1 + \
               current_customer + income + num_accounts',
               data=sub_sale_df).fit()
print(mod9.summary()) ## We may decide to keep income here
## Final model
mod10 = smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=2) * gender + age + I(age**2) + x1 + income',
               data=sub_sale_df).fit()
print(mod10.summary()) ## We may decide to keep income here

## Interestingly, income is unrelated to the model in reality (since I simulated the data I know the true relationship)
## We have found a spurious correlation with income here, probably because we considered so many potential variables
