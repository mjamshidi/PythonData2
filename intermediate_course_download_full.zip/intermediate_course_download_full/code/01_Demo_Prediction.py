
# coding: utf-8

# # Python Multivariate Analysis Demo

# *Author: Evan Carey*
# 
# *Copyright 2017, BH Analytics, LLC*

# ## Overview
# 
# The purpose of this section is to demonstrate functionality of Python that you will be learning in this course. This is a demo that goes over various aspects of multivariate binary prediction using both classical (frequentist) and machine learning approaches. 
# 
# The data used to support is a synthetic dataset representing sales data. There are two files. We will fit a model on the first file, then use the results to make prediction on the second file. 

# ## Libraries

# In[1]:

## Import Modules
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
from sklearn.metrics import confusion_matrix
import sklearn
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels


# In[2]:

## Enable inline plotting for graphics
get_ipython().magic('matplotlib inline')


# In[3]:

## Get Version information
print(sys.version)
print("Pandas version: {0}".format(pd.__version__))
print("Matplotlib version: {0}".format(matplotlib.__version__))
print("Numpy version: {0}".format(np.__version__))
print("SciKitLearn version: {0}".format(sklearn.__version__))
print("Statsmodels version: {0}".format(statsmodels.__version__))


# ## Check your working directory

# Subsequent sessions may require you to identify and update your working directory so paths correctly point at the downloaded data files. You can check your working directory like so:

# In[4]:

## Check/set your working directory
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"C:\Users\evan\Dropbox\BH_Katie_Share\Goldman_Sachs")
print("My new working directory:\n" + os.getcwd())


# ## Import the dataset

# You should already have some experience with Pandas if you are taking this course. Below, I use Pandas to import a CSV file that we will then use to fit predictive models.

# In[5]:

## Import Sales Data File
customer_sales = pd.read_csv('data/simulated_sales_data/customer_sales1.csv')
customer_sales.head()


# In[6]:

customer_sales.tail()


# ## Investigate and change dtypes

# In[7]:

customer_sales.dtypes


# In[8]:

## Change dtypes
customer_sales['customer_id'] =               customer_sales.customer_id.astype('object')
customer_sales['region'] =               customer_sales.region.astype('object')
customer_sales['current_customer'] =               customer_sales.current_customer.astype('category')
customer_sales['gender'] =               customer_sales.gender.astype('category')
customer_sales.activity.unique()


# In[9]:

customer_sales['activity'] =               pd.Categorical(customer_sales.activity,
                             ['Low','Med','High'],
                             ordered=True)
customer_sales['sale'] =               customer_sales.sale.astype('category')


# ## Dataset description
# 
# The next step should always be to examine the dataset for any issues. This dataset is very 'clean', since it is simulated data and the aim of this demo is not to show data cleaning.

# In[10]:

## describe dataset (numeric)
customer_sales.describe()


# In[11]:

## describe object dtypes
customer_sales.    select_dtypes(include=['object']).    describe()


# In[12]:

## describe categories
customer_sales.    select_dtypes(include=['category']).    describe()


# I think we need a better describe for the categories. Let's write a new function for this:

# In[13]:

## Make better categorical describe function
def describe_cats(df,normalize=False): 
    for col in df.    select_dtypes(include=['category']).    columns:
        print('\n' + col)
        print(df[col].              sort_values().              value_counts(sort=False,normalize=normalize))


# Nice! Now we can get the frequency tables for each of these vars...

# In[14]:

## Describe the cats
describe_cats(customer_sales)


# In[15]:

## Describe the cats
describe_cats(customer_sales, True)


# ## Multivariate modeling
# 
# The main goal of this demo is to show both classical (frequentist) approaches to multivariate analysis, and machine learning approaches. We will begin with  logistic regression.

# ## Classical stats: logistic regression
# 
# We implement a logistic regression using the statsmodel package. This is a form of a general linear model, where the link function is the log odds, and the family is the binomial distribution. We first need to specify a formula for the model.

# In[16]:

#### Multivariate modeling
## Use Stats models to fit logistic regression
vars_remove = ['sale','sale_amount','customer_id','region']
vars_left = set(customer_sales.columns) - set(vars_remove)
formula = "sale ~ " + " + ".join(vars_left)
formula


# We can then fit the model like so:

# In[17]:

mod1 = smf.glm(formula=formula,
               data=customer_sales, 
               family=sm.families.Binomial()).fit()
mod1.summary()


# ## Machine Learning Prediction
# 
# We will use the scikitlearn package to implement a machine learning approach to inference. We must first create numpy array of the design matrices for the regression. We can use patsy to easily do that:

# In[18]:

## use Patsy to create model matrices
Y,X = dmatrices(formula,
                customer_sales.dropna(),
                return_type="dataframe")


# We next need to split the dataset apart into testing and training datasets.

# In[19]:

## Split Data into training and sample
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test =     train_test_split(X,
                     Y['sale[Yes]'],
                     test_size=0.25,
                     random_state=42)


# Let's confirm the dimensionality of these objects...

# In[20]:

## Confirm dimensions
X_train.shape


# In[21]:

y_train.shape


# In[22]:

X_test.shape


# In[23]:

y_test.shape


# ## Null information rate
# 
# An initial concept in machine learning is the 'null information rate'. This is a silly baseline model that we know is not very good. However, it provides a useful comparison when we develop future models. What is a reasonable 'dumb' model for this binary classification problem?

# In[24]:

## Null information rate
y_test.mean()


# Scikitlearn has a built in dummy classifier that works similarly:

# In[25]:

## Dummy classifier
from sklearn.dummy import DummyClassifier
clf = DummyClassifier(strategy='most_frequent',
                      random_state=0)
clf.fit(X_train, y_train)
DummyClassifier(constant=None,
                random_state=0,
                strategy='most_frequent')
clf.score(X_test, y_test)  


# ## Penalized logistic regression
# 
# We will now use the scikitlearn package to implement a penalized logistic regression on our test dataset. We can then evaluate the results, on both the in sample data and the test dataset.

# In[26]:

## Logistic Regression with l2 penalty
from sklearn import linear_model
clf = linear_model.LogisticRegression()
clf.fit(X_train,y_train)
## get confusion matrix
confusion_matrix(y_train,clf.predict(X_train))


# In[27]:

## get accuracy
sklearn.metrics.accuracy_score(y_train,clf.predict(X_train))


# In[28]:

## Get kappa
sklearn.metrics.cohen_kappa_score(y_train,clf.predict(X_train))


# In[29]:

## get classification metrics
print(sklearn.metrics.classification_report(y_train,clf.predict(X_train)))


# Let's evaluate it against the test dataset to see if we overfit...

# In[30]:

## get classification metrics on test
print(sklearn.metrics.classification_report(y_test,clf.predict(X_test)))


# ## Logistic regression with L1 penalty
# 
# A different form of penalized logistic regression is to implement an L1 penalty. We can easily do so like this:

# In[31]:

## Logistic Regression with l1 penalty
clf = linear_model.LogisticRegression(penalty='l1')
clf.fit(X_train,y_train)
## get confusion matrix
confusion_matrix(y_train,clf.predict(X_train))


# In[32]:

## get accuracy
sklearn.metrics.accuracy_score(y_train,clf.predict(X_train))


# In[33]:

## Get kappa
sklearn.metrics.cohen_kappa_score(y_train,clf.predict(X_train))


# In[34]:

## get classification metrics
print(sklearn.metrics.classification_report(y_train,clf.predict(X_train)))


# In[35]:

## get classification metrics on test
print(sklearn.metrics.classification_report(y_test,clf.predict(X_test)))


# ## Support vector machine
# 
# Another reasonable choice for a classifer would be a support vector machine. We can easily implement this as well:

# In[36]:

## Support Vector Machine (classification)
from sklearn import svm
clf = svm.SVC()
clf.fit(X_train,y_train)
## get confusion matrix
confusion_matrix(y_train,clf.predict(X_train))


# In[37]:

## get accuracy
sklearn.metrics.accuracy_score(y_train,clf.predict(X_train))


# In[38]:

## Get kappa
sklearn.metrics.cohen_kappa_score(y_train,clf.predict(X_train))


# In[39]:

## get classification metrics
print(sklearn.metrics.classification_report(y_train,clf.predict(X_train)))


# In[40]:

## get classification metrics on test
print(sklearn.metrics.classification_report(y_test,clf.predict(X_test)))


# ## Random forest
# 
# Another possible classification routine we can use is a random forest (an ensemble of decision trees). This algorithm is very sensitive to overfitting a single sample, so I have carefully chosen a few non-default parameters:

# In[41]:

#### Fit Random Forest
## Random Forests
from sklearn import ensemble
clf = ensemble.RandomForestClassifier(n_estimators=20, 
                                      max_depth=None,
                                      min_samples_split=200,
                                      random_state=0)
clf.fit(X_train,y_train)
## get confusion matrix
confusion_matrix(y_train,clf.predict(X_train))


# In[42]:

## get accuracy
sklearn.metrics.accuracy_score(y_train,clf.predict(X_train))


# In[43]:

## Get kappa
sklearn.metrics.cohen_kappa_score(y_train,clf.predict(X_train))


# In[44]:

## get classification metrics
print(sklearn.metrics.classification_report(y_train,clf.predict(X_train)))


# In[45]:

## get classification metrics on test
print(sklearn.metrics.classification_report(y_test,clf.predict(X_test)))


# ## Score the new dataset (next year's data?)
# 
# Now that we have developed a model, we can use this model to score another dataset. In this case, we will import a similar dataset and generate predictions.

# In[46]:

## Score the new dataset using this model
## Import Sales Data File
customer_sales_2 = pd.read_csv('data/simulated_sales_data/customer_sales2.csv')
## Change dtypes
customer_sales_2['customer_id'] =               customer_sales_2.customer_id.astype('object')
customer_sales_2['region'] =               customer_sales_2.region.astype('object')
customer_sales_2['current_customer'] =               customer_sales_2.current_customer.astype('category')
customer_sales_2['gender'] =               customer_sales_2.gender.astype('category')
customer_sales_2['activity'] =               pd.Categorical(customer_sales_2.activity,
                             ['Low','Med','High'],
                             ordered=True)
customer_sales_2['sale'] =               customer_sales_2.sale.astype('category')
Y,X = dmatrices(formula,
                customer_sales_2.dropna(),
                return_type="dataframe")


# Now we can score the dataset using the model we just created:

# In[47]:

customer_sales_2['Predicated_sale'] =                 pd.Categorical.from_codes(clf.predict(X),
                                          categories=['No','Yes'])
pd.crosstab(customer_sales_2['Predicated_sale'],
            customer_sales_2['sale'])

