
# coding: utf-8

# # General Linear Regression: Poisson Regression

# *Author: Evan Carey*
# 
# *Copyright 2017, BH Analytics, LLC*

# ## Overview
# 
# The purpose of this section is to explore Poisson regression in the context of python, specifically statsmodels. We will begin by understanding exactly what Poisson regression is, and then fit increasingly complex models to make inference on the mean value of a count outcome. This is part of the general linear model family, using the link function with a Poisson distribution. 

# ## Libraries

# In[1]:

## Import Modules
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns
import textwrap


# In[2]:

## Enable inline plotting for graphics
get_ipython().magic('matplotlib inline')


# In[3]:

print(textwrap.fill(sys.version),'\n')
print("Pandas version: {0}".format(pd.__version__),'\n')
print("Matplotlib version: {0}".format(matplotlib.__version__),'\n')
print("Numpy version: {0}".format(np.__version__),'\n')
print("Statsmodels version: {0}".format(statsmodels.__version__))


# ## Check your working directory

# Subsequent sessions may require you to identify and update your working directory so paths correctly point at the downloaded data files. You can check your working directory like so:

# In[4]:

# Working Directory
import os
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"J:\Sync\Work\BHAnalytics\Python")
print("My new working directory:\n" + os.getcwd())


# ## General Linear Models

# We can generalize the ordinary linear model to a more flexible framework. In regular regression, the predictor variables are on the same scale as the outcome, and we are estimating the mean value of the outcome. We assume the sample means are normally distributed with some error. The equation for K predictors on an outcome looks like this:
# 
# $$ E(Y|X)=\beta_0 + \beta_1*X_1 + \beta_2*X_2 + ... + \beta_k*X_k + e $$
# 
# A more general framework would be to allow some function to link the predictors to the outcome (instead of assuming they are on the same scale). This is called the link function, and in normal regression it is the identity function. We can also consider different distributional families (other than normal) for the outcome. The combination of generalizing the link function and the distributional family is called a general linear model.

# ## Poisson Regression

# In Poisson regression, we are modeling a  count outcome. The outcome takes on discrete values greater than or equal to zero. The distributional family we use is the Poisson distribution. The only parameter in a Poisson distribution is lambda ($\lambda$). Lambda is both the mean and the variance for the Poisson distribution. The link function we use here is the log function. Thus, our predictor variables (and the associated beta coefficients) are on the log scale, not on the outcome scale!.
# 
# $$ log(E(Y | X)) = \beta_0 + \beta_1*X_1 + \beta_2*X_2 + ... + \beta_k*X_k$$
# 
# * What is our target of inference in this model?
# * Where is the error term?
# 
# We can do some algebraice manipulations to find the expected value of the outcome by taking the exponent of both sides of the equation:
# 
# $$ E(Y | X) = e^{\beta_0 + \beta_1*X_1 + \beta_2*X_2 + ... + \beta_k*X_k}$$
# 

# ## The Poisson Distribution

# Let's take a moment to further understand the Poisson distribution. We can use numpy to simulate some data from the Poisson distribution with different means. As we noted above, there is a single paramater, $\lambda$, which is both the mean and the variance. We will start with 1000 realizations from a Poisson distribution with $\lambda = 1$.

# In[5]:

np.random.seed(12)
samp1 = pd.DataFrame({'outcome':np.random.poisson(1,1000)})


# In[6]:

np.mean(samp1)


# In[7]:

np.var(samp1)


# As expected, both the mean and the variance are (nearly) equal to 1. We can also view the distribution like so:

# In[8]:

sns.countplot(samp1.outcome)


# In[9]:

sns.countplot(samp1.outcome, color='blue')


# In[10]:

sns.kdeplot(samp1.outcome)


# In[11]:

sns.kdeplot(samp1.outcome,
            bw=0.5)


# What happens if we increase lambda to 10? We should expect a mean and variance equal to 5. 

# In[12]:

np.random.seed(12)
samp2 = pd.DataFrame({'outcome':np.random.poisson(10,1000)})


# In[13]:

np.mean(samp2)


# In[14]:

np.var(samp2)


# In[15]:

sns.countplot(samp2.outcome,color='blue')


# In[16]:

sns.kdeplot(samp2.outcome)


# ## Fitting Our First Poisson Model

# We can use these two distributions to fit our first Poisson models and better understand the link between the estimated model coefficients and the underlying distribution of data. Let's start with an intercept only model for each sample (null model). Here is the equation we are fitting as a reminder:
# 
# 
# $$ log(E(Y | X)) = \beta_0 $$
# 
# 
# We can express this with the mean on the left hand side like so:
# 
# $$ E(Y | X) = e^{\beta_0}$$
# 

# In[17]:

## Fit simple models on this data
samp1_mod = smf.glm('outcome ~ 1',
              data=samp1,
              family=sm.families.Poisson()).fit()
print(samp1_mod.summary())


# The estimate for the intercept here is -0.0050. Why isn't it 1? Because the betas are on the log scale! In order to get the mean value of the outcome in this model, we must exponentiate the beta:
# 
# $$ E(Y | X) = e^{\beta_0}$$
# 
# $$ E(Y | X) = e^{-0.005}$$

# In[18]:

## Recover coef
samp1_mod.params


# In[19]:

np.exp(samp1_mod.params[0])


# Let's fit the other model on the distributon with $\lambda = 10$

# In[20]:

samp2_mod = smf.glm('outcome ~ 1',
              data=samp2,
              family=sm.families.Poisson()).fit()
print(samp2_mod.summary())


# In[21]:

## Estimate mean
np.exp(samp2_mod.params[0])


# In[22]:

## Compare to mean
samp2.mean()


# In[23]:

## Compare to Variance
samp2.var()


# ## Applied Poisson Regression Example: The Rand Health Data

# We will use the Rand Health data that is included with statsmodels for the applied section of Poisson modelling. You can call the data into memory using the following code:

# In[24]:

## Import Data
rand_hie = statsmodels.datasets.randhie.load_pandas().data


# We can examine information about the data like so:

# In[25]:

print(statsmodels.datasets.randhie.NOTE)


# As always, let's first check the top and bottom of the data and some basic descriptions:

# In[26]:

rand_hie.head()


# In[27]:

rand_hie.tail()


# In[28]:

rand_hie.dtypes


# In[29]:

## Describe data
rand_hie.describe()


# We will be focusing on the outcome 'mdvis', which is the number of doctors visits. Let's further examine this variable:

# In[30]:

rand_hie.mdvis.mean()


# In[31]:

rand_hie.mdvis.var()


# Is the assumption of mean = variance reasonable here? 

# In[32]:

## Examine outcome
sns.countplot(rand_hie.mdvis,color='blue')


# ## RAND Data: Null Model

# The first model we will fit is the null model, or the intercept only model. 

# In[33]:

## Fit basic glm with Poisson
mod0 = smf.glm('mdvis ~ 1',
              data=rand_hie,
              family=sm.families.Poisson()).fit()
print(mod0.summary())


# We can interpret the exponentiating intercept as the estimate of the mean:

# In[34]:

## Estimate mean
np.exp(mod0.params)


# In[35]:

rand_hie.mdvis.mean()


# Notice the estimate of the mean is unbiased, even though the variance is likely underestimated. This data is very overdispersed (extra variation beyond the Poisson assumption). We will talk more on this later!

# In[36]:

rand_hie.mdvis.var()


# ## Add Predictors into the Model

# 

# In[37]:

## Examine potential predictors
rand_hie.dtypes


# In[38]:

rand_hie.corr()


# We will start by examining idp, which is binary variable indicating if the individual is on the deductible plan or not. First, let's calculate the group by means:

# In[39]:

rand_hie.groupby('idp').mdvis.mean()


# It looks like patients with an individual deductable plan have a lower mean number of physicians visits (the difference is about 0.52). Let's fit the same model using a Poisson regression. Here is the model we are fitting:
# 
# 
# $$ log(\overline{mdvis}) = \beta_0 + \beta_{idp} * idp $$
# 
# 
# What do you expect to get for the value of $\beta_0$? What about $\beta_{idp}$?

# In[40]:

## Fit idp model
mod1= smf.glm('mdvis ~ idp',
              data=rand_hie,
              family=sm.families.Poisson()).fit()
print(mod1.summary())


# Here are the model estimates:
# 
# 
# $$ log(\overline{mdvis}) = 1.097 - 0.192 * idp $$
# 
# 
# We are expecting an absolute difference of about 0.52 for this model. Why did we get -0.192? Because the betas are on the log scale. Instead of fitting an additive model, we have fit a multiplicative model. With some algebra, we can show the following is true:
# 
# $$ \overline{mdvis} = e^{\beta_0 + \beta_{idp} * idp} $$
# 
# 
# $$ \overline{mdvis} = e^{\beta_0} * e^{\beta_{idp} * idp} $$
# 
# Therefore, the appropriate interpretation of of the beta coefficients for idp is multiplicative. If we exponentiate the beta, we get the multiplicative effect of idp. In this case it is:
# 
# $$e^{\beta_{idp} * idp}$$

# In[41]:

mod1.params['idp']


# In[42]:

np.exp(mod1.params['idp'])


# We can say that patients with status idp == 1 have mean mdvis that is changed by a factor of 0.82 (or a decrease of about 18%).  

# In[43]:

res1 = rand_hie.groupby('idp').mdvis.mean()
res1


# In[44]:

(res1[1] - res1[0]) / res1[0]


# We can see that this is true in our basic calculations outside of the model as well. 

# ## Adding More Predictors Into the Model

# We can add even more predictors into the model, just as we might with other forms of general linear regression. All the prior lessons on non-linearity, confounding, and interaction apply here. For now I will just fit a model with linear terms and no interactions.

# In[45]:

## Fit more variables in the model
mod2 = smf.glm('mdvis ~ lncoins + idp + lpi + fmde + physlm + disea',
              data=rand_hie,
              family=sm.families.Poisson()).fit()
print(mod2.summary())


# In this model all of the variables are significant predictors of the outcome. Did IDP become stronger or weaker once we added in the other variables?
# 
# All of these coefficients can be interpreted similary as how we did the binary variable above. Let's repeat the interpretation for idp:

# In[46]:

np.exp(mod2.params)


# Now IDP is associated with a change in the mean number of MD visits by a factor of 0.77 (a decrease). Conversely, Physlm (physical limiation) shows a positive effect. The mean number of MD Visits for Patients with a physical limitation is 34% higher compared to those without a physical limitation. The number of chronic diseases is also associated with the mean number of physician visits. For every additional chronic disease (disea), the mean number of physician visits increases by 3.5%. I will leave the rest of the interpretations as an exercise to the reader.
