########################################################################
## Title: Solution to Fraud Exercise
## Author: Evan Carey, written for BH Analytics, LLC
## Date Created: 2017-04-19
########################################################################

## Import Modules
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
from sklearn.metrics import confusion_matrix
import sklearn
from sklearn import datasets
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns

## Get Version information
print(sys.version)
print("Pandas version: {0}".format(pd.__version__))
print("Matplotlib version: {0}".format(matplotlib.__version__))
print("Numpy version: {0}".format(np.__version__))
print("Seaborn version: {0}".format(sns.__version__))

# Working Directory
import os
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"J:\Sync\bh_share\Deloitte_New_Hire_v2\course_download")
print("My new working directory:\n" + os.getcwd())

## import data
fraud_df = pd.read_csv(r'data\creditcardfraud\creditcard.csv')

## Examine Data
fraud_df.shape
fraud_df.head()
fraud_df.tail()
fraud_df.describe()

## Look at outcome
fraud_df.Class.value_counts()
fraud_df.Class.value_counts(normalize=True)

## Examine the distribution of the VXX vars
fraud_df.describe()
## Look at a dist plot for each one
for col in fraud_df.columns[fraud_df.columns.str.startswith('V')]:
    plt.figure()
    sns.distplot(fraud_df[col])

## Examine distribution of time
fraud_df.Time.describe()
fraud_df.Time.hist(bins=100)
sns.distplot(fraud_df.Time)
## Create indicator variable for time in second 'hump'
fraud_df['Time_cat'] = np.where(fraud_df.Time < 100000,'Early','Late')

## Check the distribution of fraud in those periods
pd.crosstab(fraud_df.Class,fraud_df.Time_cat)
pd.crosstab(fraud_df.Class,fraud_df.Time_cat,
            normalize=1)

## Create formula for all variables in model
vars_remove = ['Time','Class','Time_cat']
vars_left = set(fraud_df.columns) - set(vars_remove)
formula = "Class ~ " + " + ".join(vars_left)
formula

## Split Data into training and sample using time
## use Patsy to create model matrices
Y_train,X_train = dmatrices(formula,
                            fraud_df[fraud_df.Time_cat == 'Early'])
Y_test,X_test = dmatrices(formula,
                          fraud_df[fraud_df.Time_cat == 'Late'])
## Check dimensionality
Y_train.shape # needs to be 1D object
Y_train = Y_train[:,0]
X_train.shape
Y_test.shape # needs to be 1D object
Y_test = Y_test[:,0]
X_test.shape

##### Fit Models ####
## Create dict to store all these results:
result_scores = {}
## Create Function to Print Results
def get_results(x1):
    print("\n{0:12}   {1:<6}    {2:<6}".format('Model','Train','Test'))
    print('--------------------------------')
    for i in x1.keys():
        print("{0:12}   {1:<6.3}    {2:<6.3}".format(i,x1[i][0],x1[i][1]))
get_results(result_scores)

#### Dummy classifier
from sklearn.dummy import DummyClassifier
clf = DummyClassifier(strategy='most_frequent',
                      random_state=0)
clf.fit(X_train, Y_train)
clf.score(X_train, Y_train)
sklearn.metrics.cohen_kappa_score(Y_train,clf.predict(X_train))
## Score the Model on Training and Testing Set, pick kappa instead of accuracy
result_scores['Mean'] = (sklearn.metrics.cohen_kappa_score(Y_train,clf.predict(X_train)),
             sklearn.metrics.cohen_kappa_score(Y_test,clf.predict(X_test)))
## Print results
get_results(result_scores)

#### Fit Logistic Regression
## import linear model
from sklearn import linear_model
## Define model parameters
mod_logit = linear_model.LogisticRegression()
## fit model using data with .fit
mod_logit.fit(X_train,Y_train)
result_scores['logistic'] = (sklearn.metrics.cohen_kappa_score(Y_train,mod_logit.predict(X_train)),
             sklearn.metrics.cohen_kappa_score(Y_test,mod_logit.predict(X_test)))
## Print results
get_results(result_scores)

#### Fit LASSO Logsitic Regression
## import linear model
from sklearn import linear_model
## Define model parameters
mod_logit = linear_model.LogisticRegression()
## fit model using data with .fit
mod_logit.fit(X_train,Y_train)
result_scores['logistic'] = (sklearn.metrics.cohen_kappa_score(Y_train,mod_logit.predict(X_train)),
             sklearn.metrics.cohen_kappa_score(Y_test,mod_logit.predict(X_test)))
## Print results
get_results(result_scores)

#### Fit Logistic Regression LASSO
from sklearn.preprocessing import PolynomialFeatures
from sklearn import preprocessing
from sklearn.pipeline import Pipeline

clf = linear_model.LogisticRegressionCV(Cs=[0.1, 0.15, 0.2, 0.5,1],
                                        cv=10)
scaler = preprocessing.StandardScaler()
poly_feat = PolynomialFeatures(degree=2,include_bias=False)
pipe_LASSO = Pipeline([("scale", scaler),
                  ("poly",poly_feat),
                  ("lasso", clf)])
## fit model using data with .fit
pipe_LASSO.fit(X_train,Y_train)

## Score the results
result_scores['LASSO'] = (sklearn.metrics.cohen_kappa_score(Y_train,pipe_LASSO.predict(X_train)),
             sklearn.metrics.cohen_kappa_score(Y_test,pipe_LASSO.predict(X_test)))
## Print results
get_results(result_scores)

#### Fit Random Forest
from sklearn import ensemble
clf_RF = ensemble.RandomForestClassifier(n_estimators=20, 
                                      max_depth=None,
                                      min_samples_split=200,
                                      random_state=0)
clf_RF.fit(X_train,Y_train)
## Score the results
result_scores['RandomF'] = (sklearn.metrics.cohen_kappa_score(Y_train,clf_RF.predict(X_train)),
             sklearn.metrics.cohen_kappa_score(Y_test,clf_RF.predict(X_test)))
## Print results
get_results(result_scores)
## get confusion matrix
confusion_matrix(Y_test,clf_RF.predict(X_test))

#### Fit SVM
from sklearn import svm
clfSV = svm.SVC()
clfSV.fit(X_train,Y_train)
## Score the results
result_scores['SVM'] = (sklearn.metrics.cohen_kappa_score(Y_train,clfSV.predict(X_train)),
             sklearn.metrics.cohen_kappa_score(Y_test,clfSV.predict(X_test)))
## Print results
get_results(result_scores)

