
# coding: utf-8

# # Linear Regression 2

# *Author: Evan Carey*
# 
# *Copyright 2017, BH Analytics, LLC*

# ## Overview
# 
# The purpose of this section is to extend your understanding of linear regression. In this module, we will be covering the concepts of non-linearity in a model, confounding, interaction, and model selection. 

# ## Libraries

# In[1]:

## Import Modules
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns
import textwrap


# In[2]:

## Enable inline plotting for graphics
get_ipython().magic('matplotlib inline')

## Set print options
pd.options.display.max_rows = 10


# In[3]:

print(textwrap.fill(sys.version),'\n')
print("Pandas version: {0}".format(pd.__version__),'\n')
print("Matplotlib version: {0}".format(matplotlib.__version__),'\n')
print("Numpy version: {0}".format(np.__version__),'\n')
print("Statsmodels version: {0}".format(statsmodels.__version__))


# ## Check your working directory

# Subsequent sessions may require you to identify and update your working directory so paths correctly point at the downloaded data files. You can check your working directory like so:

# In[4]:

# Working Directory
import os
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"C:\Users\evan\Dropbox\BH_Katie_Share\Goldman_Sachs")
print("My new working directory:\n" + os.getcwd())


# ## Motivating Example: Sales data

# For this section, we will use some sales data as a motivating example. This is a simulated dataset with both a binary outcome (sale) and a continuous outcome (sale_amount). We will focus on a subset of the data with positive sale amounts. First, we should import the data. 

# In[5]:

## import data
sale_df = pd.read_csv(r'data\Simulated_sales_data\customer_sales1.csv')


# In[6]:

sale_df


# In[7]:

## Subset down to only the rows with sales
sub_sale_df = sale_df.loc[sale_df.sale_amount>0,].copy()


# In[8]:

print(sub_sale_df.describe())


# ## Examine the Distribution of the Outcome

# We can start by looking at the distribution of the outcome to get a sense of the data.

# In[9]:

sns.distplot(sub_sale_df.sale_amount)


# This looks like a typical strictly positive distribution. Since it is not possible to have a negative sale price, we see a bit of skew, with most of the data focused on lower priced items, and a smaller amount of data in the higher priced items. 
# 
# This data is not normally distributed, however, we can still use linear regression to make inference on the mean due to the central limit theorem. In subsequent modules we will consider different forms of general linear regression that may also be appropriate for this data. 
# 
# Our target of inference here is the sample mean, so we are interested in getting the best estimate of the sample mean, given the potential predictors. We can start but just calculating the sample mean as an initial estimator:

# In[10]:

sub_sale_df.sale_amount.mean()


# In[11]:

mod0 = smf.ols('sale_amount ~ 1', data=sub_sale_df).fit()
print(mod0.summary())


# ## Age by Sale Amount

# We can investigate the relationship between age and mean sale amount. If we simply include age in the model as a linear predictor, we are assuming a linear relationship between these variables. Is that appropriate here?

# In[12]:

sns.regplot(x='age',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})


# It looks like there is a non-linear relationship between age and the sale amount. In this case, we may be able to approximate it using a simply polynomial like this:

# In[13]:

sns.regplot(x='age',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'},
            order=2)


# This looks like a good fit to the data. We can fit this in the linear model like so:

# In[14]:

mod1 = smf.ols('sale_amount ~ age + I(age**2)',
               data=sub_sale_df).fit()
print(mod1.summary())


# The p-values for the age and age-squared term indicate that this is a reasonable fit for the model. However, there is clearly still a large amount of variation left-over in this model (as evidenced by the errors around the predicted sample mean). 

# ## Non-Linearity: Marketing Exposure

# We may also be interested in estimating the effect of marketing exposure on the sale amount. Let's begin by visualizing the relationship between these variables alone:

# In[15]:

sns.regplot(x='marketing_exposure',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})


# It looks like there is an overall negative effect of marketing exposure! The more marketing exposure someone recieves, the less likely they are to buy the product?!? We will find this is not the case in the end, but let's continue with this pairwise investigation for now. 

# In[16]:

mod2= smf.ols('sale_amount ~ marketing_exposure',
               data=sub_sale_df).fit()
print(mod2.summary())


# ## Non-Linearity: Splines and Marketing Exposure

# We can further examine this relationship by looking at a non-linear fit for this data. 

# In[17]:

sns.lmplot(x='marketing_exposure',
           y='sale_amount',
           data=sub_sale_df,
           scatter_kws={'alpha':0.3},
           line_kws={'color': 'black'},
           lowess=True)


# The non-linear fit gives us a similar answer as the linear fit. We can fit a flexible line in the context of regression by using splines. The general idea is that we split the data up into regions, then fit a polynomial within each region that connects. It is pretty straightforward to fit a spline model using statsmodels and patsy, but the output can be difficult to understand. We need to define the number of knots (the place we will split intp different regions). We do this by defining the degress of freedom. 

# In[18]:

mod3= smf.ols('sale_amount ~ bs(marketing_exposure,3)',
               data=sub_sale_df).fit()
print(mod3.summary())


# We can visualize the spline we just fit by running some predictions through the model like so:

# In[19]:

df_temp = pd.DataFrame({'marketing_exposure':np.arange(14)})
df_temp['pred_sale_amount'] = mod3.predict(df_temp)


# In[20]:

sns.lmplot(x='marketing_exposure',
           y='pred_sale_amount',
           data=df_temp,
           fit_reg=False)


# We can specify the degree of the polynomials used, by saying degree == 1, we are asking for straight lines in each region. 

# In[21]:

mod4= smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=1)',
               data=sub_sale_df).fit()
print(mod4.summary())


# In[22]:

df_temp = pd.DataFrame({'marketing_exposure':np.arange(14)})
df_temp['pred_sale_amount'] = mod4.predict(df_temp)
sns.lmplot(x='marketing_exposure',
           y='pred_sale_amount',
           data=df_temp,
           fit_reg=False)


# ## Interaction Effects: Gender by Marketing Exposure

# This is an odd relationship...the more marketing exposure, the less sale amount? Perhaps there is something else going on here. Gender may also play a role...let's examine the relationship between marketing exposure and sale amount for each gender seperately. 

# In[23]:

sns.lmplot(x='marketing_exposure',
           y='sale_amount',
           data=sub_sale_df,
           scatter_kws={'alpha':0.3},
           line_kws={'color': 'black'},
           lowess=True,
          col='gender')


# 
# This result looks very different than what we just found! We are seeing that there is a positive effect of marketing exposure in females that seems to plateau...but there is no effect in males. This is plausible, but how would we fit this in our model? We do this by including an interaction term between these variables. The interacton term is denoted by the * sign. It is a literal multiplication of the two terms together. We will start by adding gender into the model, then also adding the interaction so we have a comparison. 

# In[24]:

## Add gender into the model, no interaction yet
mod5 = smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=1) + gender',
               data=sub_sale_df).fit()
print(mod5.summary())


# In[25]:

## Add gender into the model with interaction 
mod6 = smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=2) * gender',
               data=sub_sale_df).fit()
print(mod6.summary())


# Which p-value do we interpret?!? We can compare the models based on the AIC (lower is better), or also by performing a likelihood ratio test since these are nested. 

# ## Comparing Model Fits: AIC

# We can compare using the AIC, which is a penalized likelihood based statistic. In general, the lower the number the better.

# In[26]:

print("model-6 AIC: ", mod6.aic)
print("model-5 AIC: ", mod5.aic)


# ## Comparing Model Fits: Likelihood Ratio Test

# We can use a LRT for models that are “nested”, Meaning one model can be recovered from the other by deleting parameters…

# * If they are not nested, we must use AIC.

# In[27]:

## Compare Model fits - likelihood
print("model-6 LLF: ", mod6.llf)
print("model-5 LLF: ", mod5.llf)


# In[28]:

## Likelihood ratio test
print(sm.stats.anova_lm(mod5,mod6))


# In both cases, we see that model 6 is an improvement over model 5. 

# ## Understanding the Interaction and Spline Terms

# If we want to really understand the spline term interaction we just fit, we must again make some predictions to visualize the result of the model terms. 

# In[29]:

df_temp = pd.DataFrame({'marketing_exposure':list(range(14))*2,
                        'gender':['Male']*14 + ['Female']*14})


# In[30]:

df_temp


# In[31]:

df_temp['pred_sale_amount'] = mod6.predict(df_temp)
fig, ax = plt.subplots(figsize=(8,6))
for label, df in df_temp.groupby('gender'):
    df.plot(x='marketing_exposure',y='pred_sale_amount',ax=ax, label=label)
plt.legend()


# ## Confounding

# Let's examine the relationship between gender and the mean sale amount. We can start with a box plot like this:

# In[32]:

## Compare sale_amount across gender
sns.boxplot(x="gender", 
            y="sale_amount",
            data=sub_sale_df)


# It looks like males have a lower average sale amount than females. We can fit a simple linear model with gender as a predictor to estimate the mean difference. 

# In[33]:

mod7 = smf.ols('sale_amount ~ gender',
               data=sub_sale_df).fit()
print(mod7.summary())


# We find a highly significant difference here, with males having a lower average sale amount than females. But recall, we also found that age and marketing exposure were associated with sale amount. What if we include all of these variables? 

# However, what happens when we include marketing exposure and also age in the model?

# In[34]:

mod8 = smf.ols('sale_amount ~ bs(marketing_exposure,3,degree=2) * gender + age + I(age**2)',
               data=sub_sale_df).fit()
print(mod8.summary())


# We now see essentially no effect of gender, with a large p-value! This is odd...it turns out the observed relationship between gender and sale amount was actually just the result of confounding with age and marketing exposure. 
