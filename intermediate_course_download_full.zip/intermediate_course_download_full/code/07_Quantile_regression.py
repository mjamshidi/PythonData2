
# coding: utf-8

# # Quantile Regression

# *Author: Evan Carey*
# 
# *Copyright 2017, BH Analytics, LLC*

# ## Overview
# 
# The purpose of this section is to cover quantile regression in the context of Python, specifically the statsmodels module. We will first think about why we might use quantile regression, then implement some models. 

# ## Libraries

# In[1]:

## Import Modules
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns
import textwrap


# In[2]:

## Enable inline plotting for graphics
get_ipython().magic('matplotlib inline')

## Set print options
pd.options.display.max_rows = 10


# In[3]:

print(textwrap.fill(sys.version),'\n')
print("Pandas version: {0}".format(pd.__version__),'\n')
print("Matplotlib version: {0}".format(matplotlib.__version__),'\n')
print("Numpy version: {0}".format(np.__version__),'\n')
print("Statsmodels version: {0}".format(statsmodels.__version__))


# ## Check your working directory

# Subsequent sessions may require you to identify and update your working directory so paths correctly point at the downloaded data files. You can check your working directory like so:

# In[4]:

# Working Directory
import os
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"J:\Sync\Work\BHAnalytics\Python")
print("My new working directory:\n" + os.getcwd())


# ## Motivating Example: Sales data

# For this section, we will use some sales data as a motivating example. This is a simulated dataset with both a binary outcome (sale) and a continuous outcome (sale_amount). We will focus on a subset of the data with positive sale amounts. First, we should import the data. 

# In[5]:

## import data
sale_df = pd.read_csv(r'data\Simulated_sales_data_2\customer_sales1.csv')


# In[6]:

sale_df


# In[7]:

## Subset down to only the rows with sales
sub_sale_df = sale_df.loc[sale_df.sale_amount>0,].copy()


# In[8]:

print(sub_sale_df.describe())


# ## Examine the Distribution of the Outcome

# We can start by looking at the distribution of the outcome to get a sense of the data.

# In[9]:

sns.distplot(sub_sale_df.sale_amount)


# This looks like a typical strictly positive distribution. Since it is not possible to have a negative sale price, we see a bit of skew, with most of the data focused on lower priced items, and a smaller amount of data in the higher priced items. 
# 
# Although it would be reasonable to use linear regression in this problem, we may decide to implement quantile regression if we desire to make inference on the median, or perhaps the 75 percentile, rather than the mean. In that case, we must use quantile regression. Quantile regression works very similarly to linear regression in practice using Python, however, the underlying optimization is different. We will make inference on the 75 percentile for this exercise, but you could choose any percentile. 

# In[10]:

sub_sale_df.sale_amount.quantile([0.75])


# In[11]:

mod0 = smf.quantreg('sale_amount ~ 1',
                    data=sub_sale_df).fit(q=0.75)
print(mod0.summary())


# ## Age by Sale Amount

# We can investigate the relationship between age and the 75 percentile of sale amount. If we simply include age in the model as a linear predictor, we are assuming a linear relationship between these variables. Is that appropriate here?

# In[12]:

sns.regplot(x='age',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})


# It looks like there is a non-linear relationship between age and the sale amount. In this case, we may be able to approximate it using a simply polynomial like this:

# In[13]:

sns.regplot(x='age',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'},
            order=2)


# This looks like a good fit to the data. We can fit this in the linear model like so:

# In[14]:

mod1 = smf.quantreg('sale_amount ~ age + I(age**2)',
                    data=sub_sale_df).fit(q=0.75)
print(mod1.summary())


# We are seeing some convergence issue with this model. This indicates we may be unable to get the model to converge with a polynomial term for age. Interestingly, this is not true for the median:

# In[15]:

mod1 = smf.quantreg('sale_amount ~ age + I(age**2)',
                    data=sub_sale_df).fit(q=0.5)
print(mod1.summary())


# The model with the median converged without warning, and gave similar results. I might trust the original model of the 75 percentile, even though there were convergence warnings. 

# ## Non-Linearity: Marketing Exposure

# We may also be interested in estimating the effect of marketing exposure on the sale amount. Let's begin by visualizing the relationship between these variables alone:

# In[16]:

sns.regplot(x='marketing_exposure',
            y='sale_amount',
            data=sub_sale_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'})


# It looks like there is an overall negative effect of marketing exposure! The more marketing exposure someone recieves, the less likely they are to buy the product?!? We will find this is not the case in the end, but let's continue with this pairwise investigation for now. 

# In[17]:

mod2 = smf.quantreg('sale_amount ~ marketing_exposure',
                    data=sub_sale_df).fit(q=0.75)
print(mod2.summary())


# ## Non-Linearity: Splines and Marketing Exposure

# We can further examine this relationship by looking at a non-linear fit for this data. 

# In[18]:

sns.lmplot(x='marketing_exposure',
           y='sale_amount',
           data=sub_sale_df,
           scatter_kws={'alpha':0.3},
           line_kws={'color': 'black'},
           lowess=True)


# The non-linear fit gives us a similar answer as the linear fit. We can fit a flexible line in the context of regression by using splines. The general idea is that we split the data up into regions, then fit a polynomial within each region that connects. It is pretty straightforward to fit a spline model using statsmodels and patsy, but the output can be difficult to understand. We need to define the number of knots (the place we will split intp different regions). We do this by defining the degress of freedom. 

# In[19]:

mod3= smf.quantreg('sale_amount ~ bs(marketing_exposure,3)',
                   data=sub_sale_df).fit(q=0.75)
print(mod3.summary())


# We can visualize the spline we just fit by running some predictions through the model like so:

# In[20]:

df_temp = pd.DataFrame({'marketing_exposure':np.arange(14)})
df_temp['pred_sale_amount'] = mod3.predict(df_temp)


# In[21]:

sns.lmplot(x='marketing_exposure',
           y='pred_sale_amount',
           data=df_temp,
           fit_reg=False)


# We can specify the degree of the polynomials used, by saying degree == 1, we are asking for straight lines in each region. 

# In[22]:

mod4 = smf.quantreg('sale_amount ~ bs(marketing_exposure,3,degree=1)',
                    data=sub_sale_df).fit(q=0.75)
print(mod4.summary())


# In[23]:

df_temp = pd.DataFrame({'marketing_exposure':np.arange(14)})
df_temp['pred_sale_amount'] = mod4.predict(df_temp)
sns.lmplot(x='marketing_exposure',
           y='pred_sale_amount',
           data=df_temp,
           fit_reg=False)


# ## Interaction Effects: Gender by Marketing Exposure

# This is an odd relationship...the more marketing exposure, the less sale amount? Perhaps there is something else going on here. Gender may also play a role...let's examine the relationship between marketing exposure and sale amount for each gender seperately. 

# In[24]:

sns.lmplot(x='marketing_exposure',
           y='sale_amount',
           data=sub_sale_df,
           scatter_kws={'alpha':0.3},
           line_kws={'color': 'black'},
           lowess=True,
          col='gender')


# 
# This result looks very different than what we just found! We are seeing that there is a positive effect of marketing exposure in females that seems to plateau...but there is no effect in males. This is plausible, but how would we fit this in our model? We do this by including an interaction term between these variables. The interacton term is denoted by the * sign. It is a literal multiplication of the two terms together. We will start by adding gender into the model, then also adding the interaction so we have a comparison. 

# In[25]:

## Add gender into the model, no interaction yet
mod5 = smf.quantreg('sale_amount ~ bs(marketing_exposure,3,degree=1) + gender',
                    data=sub_sale_df).fit(q=0.75)
print(mod5.summary())


# In[26]:

## Add gender into the model with interaction 
mod6 = smf.quantreg('sale_amount ~ bs(marketing_exposure,3,degree=2) * gender',
                    data=sub_sale_df).fit(q=0.75)
print(mod6.summary())


# ## Understanding the Interaction and Spline Terms

# If we want to really understand the spline term interaction we just fit, we must again make some predictions to visualize the result of the model terms. 

# In[27]:

df_temp = pd.DataFrame({'marketing_exposure':list(range(14))*2,
                        'gender':['Male']*14 + ['Female']*14})


# In[28]:

df_temp


# In[29]:

df_temp['pred_sale_amount'] = mod6.predict(df_temp)
fig, ax = plt.subplots(figsize=(8,6))
for label, df in df_temp.groupby('gender'):
    df.plot(x='marketing_exposure',y='pred_sale_amount',ax=ax, label=label)
plt.legend()

