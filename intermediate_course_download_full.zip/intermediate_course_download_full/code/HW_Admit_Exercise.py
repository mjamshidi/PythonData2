########################################################################
## Title: Solution to Berkeley Admissions Exercise
## Author: Evan Carey, written for BH Analytics, LLC
## Date Created: 2017-04-19
########################################################################

## import modules
import pandas as pd 
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns
import os
import sys

## Get Version information
print(sys.version)
print("Pandas version: {0}".format(pd.__version__))
print("Matplotlib version: {0}".format(matplotlib.__version__))
print("Numpy version: {0}".format(np.__version__))
print("Seaborn version: {0}".format(sns.__version__))

# Working Directory
import os
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"J:\Sync\Work\BHAnalytics\Python")
print("My new working directory:\n" + os.getcwd())

## import data
berkeley_df = pd.read_csv(r'data\berkleydf.csv')

## Examine Data
berkeley_df.describe()

## Look at frequency tables
berkeley_df.Admit.value_counts()
berkeley_df.Admit.value_counts(normalize=True)
berkeley_df.Gender.value_counts()
berkeley_df.Gender.value_counts(normalize=True)
berkeley_df.Dept.value_counts()
berkeley_df.Dept.value_counts(normalize=True)

## Look at Overall relationship between gender and admit status
pd.crosstab(berkeley_df.Gender,
            berkeley_df.Admit,
            normalize=0)
## Calculate Chi square
from scipy.stats import chi2_contingency
tbl1  = pd.crosstab(berkeley_df.Gender,berkeley_df.Admit)
chi2, p, ddof, expected = chi2_contingency(tbl1)
msg = "Test Statistic: {}\np-value: {}\nDegrees of Freedom: {}\n"
print(msg.format(chi2, p, ddof))
## Only 30 percent of females are admitted, compared with 44% of Males!
## Here is a logistic regression showing the same result!
mod1 = smf.glm('Admit ~ Gender',
              data=berkeley_df,
              family=sm.families.Binomial()).fit()
print(mod1.summary())
## This is a statistically significant result!

## But what about the other variables in this system? 
## Is Gender related to Dept? Is Dept related to Admit?
pd.crosstab(berkeley_df.Dept,
            berkeley_df.Admit,
            normalize=0)
## clearly admit is related to department
pd.crosstab(berkeley_df.Dept,
            berkeley_df.Gender,
            normalize=0)
# Gender is also related to department!
## Can we make a table of the probability of admission by gender and department?
tbl1 = pd.crosstab(index=[berkeley_df.Dept,berkeley_df.Gender],
            columns=berkeley_df.Admit,
            normalize=0)
## Reshape the table and only show the admission rates
tbl1_admit = tbl1['Admitted']
tbl1_admit.unstack(level='Gender')
## It looks like admission rates do not vary by gender and department!
## Here is a statistical model showing the same thing:
mod2 = smf.glm('Admit ~ Gender + Dept',
              data=berkeley_df,
              family=sm.families.Binomial()).fit()
print(mod2.summary())
## Gender is no longer significant after adjusting for Dept
## What is happening is that Males are applying in larger numbers
## to the departments that are easier to get into! Thus there appears
## to be a gender bias, when there is really only a dept bias. 
