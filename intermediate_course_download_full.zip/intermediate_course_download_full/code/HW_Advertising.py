########################################################################
## Title: Solution to Advertising Exercise
## Author: Evan Carey, written for BH Analytics, LLC
## Date Created: 2017-04-19
########################################################################

## import modules
import pandas as pd 
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns
import os
import sys

## Get Version information
print(sys.version)
print("Pandas version: {0}".format(pd.__version__))
print("Matplotlib version: {0}".format(matplotlib.__version__))
print("Numpy version: {0}".format(np.__version__))
print("Seaborn version: {0}".format(sns.__version__))

# Working Directory
import os
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"J:\Sync\Work\BHAnalytics\Python")
print("My new working directory:\n" + os.getcwd())

## import data
advert_df = pd.read_csv(r'data\Advertising.csv')
## Change Region Column Name
advert_df.rename(columns={'Unnamed: 0':'Region'}, inplace=True)

## Describe Sales
advert_df.Sales.describe()
advert_df.Sales.mean()
sns.distplot(advert_df.Sales)

## Fit null model (intercept only model)
mod0 = smf.ols('Sales ~ 1', data=advert_df).fit()
mod0.summary()

## Examine TV with mean sales
sns.regplot(x='TV',
            y='Sales',
            data=advert_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'},
            lowess=True)

## Examine Radio with mean sales
sns.regplot(x='Radio',
            y='Sales',
            data=advert_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'},
            lowess=True)

## Examine Newspaper with mean sales
sns.regplot(x='Newspaper',
            y='Sales',
            data=advert_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'},
            lowess=False)

## Linear correlation for all predictors with Sales
advert_df.corr().Sales
## Get P values
from scipy.stats import pearsonr
r, p = \
    pearsonr(advert_df.Sales,
             advert_df.TV)
msg = "Correlation: {}\np-value: {}\n"
print(msg.format(r, p))
r, p = \
    pearsonr(advert_df.Sales,
             advert_df.Radio)
msg = "Correlation: {}\np-value: {}\n"
print(msg.format(r, p))
r, p = \
    pearsonr(advert_df.Sales,
             advert_df.Newspaper)
msg = "Correlation: {}\np-value: {}\n"
print(msg.format(r, p))
## All predictors are related to the outcome some amount

## Check if the predictors are related
advert_df.loc[:,['TV','Radio','Newspaper']].corr()
r, p = \
    pearsonr(advert_df.Radio,
             advert_df.TV)
msg = "Correlation: {}\np-value: {}\n"
print(msg.format(r, p))
r, p = \
    pearsonr(advert_df.Radio,
             advert_df.Newspaper)
msg = "Correlation: {}\np-value: {}\n"
print(msg.format(r, p))
r, p = \
    pearsonr(advert_df.TV,
             advert_df.Newspaper)
msg = "Correlation: {}\np-value: {}\n"
print(msg.format(r, p))
## It looks like Radio is associated with Newspaper
sns.regplot(x='Newspaper',
            y='Radio',
            data=advert_df,
            scatter_kws={'alpha':0.3},
            line_kws={'color': 'black'},
            lowess=False)
## Fit pairwise models
mod1 = smf.ols('Sales ~ TV', data=advert_df).fit()
mod1.summary()
mod2 = smf.ols('Sales ~ Radio', data=advert_df).fit()
mod2.summary()
mod3 = smf.ols('Sales ~ Newspaper', data=advert_df).fit()
mod3.summary()


## Include all predictors in the model
mod4 = smf.ols('Sales ~ Newspaper + TV + Radio', data=advert_df).fit()
mod4.summary()
## Newspaper is no longer significant, it was just confounded with Radio
## Radio has the largest coefficient, so most impact per dollar spent?

## Consider interaction between TV and Radio
mod5 = smf.ols('Sales ~ TV*Radio', data=advert_df).fit()
mod5.summary()

## Consider non-linear fit for TV
mod5 = smf.ols('Sales ~ Radio + TV + I(TV**2)', data=advert_df).fit()
mod5.summary()

## Consider non-linear fit for Newspaper?
mod6 = smf.ols('Sales ~ Newspaper + I(Newspaper**2) + TV + I(TV**2)', data=advert_df).fit()
mod6.summary()
