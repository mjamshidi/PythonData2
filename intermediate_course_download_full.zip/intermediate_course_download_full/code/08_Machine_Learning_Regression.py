
# coding: utf-8

# # Machine Learning Regression

# *Author: Evan Carey*
# 
# *Copyright 2017, BH Analytics, LLC*

# ## Overview
# 
# The purpose of this section is to go over machine learning, specifically regression, in the context of python (the scikitlearn module). We will include general concepts of machine learning as well as the specifics of a few different regression algorithms. For further reading, I highly recommend the free ebook titled 'Introduction to Statistical Learning' by Gareth James. A quick web search should find this book near the top of the search results. For even more in-depth coverage of machine learning algorithms, I recommend the book  'Elements of Statistical Learning' by Trevor Hastie (also free online). 
# 
# The data used to support this section is a synthetic dataset representing sales data. There are two files. We will fit a model on the first file, then use the results to make prediction on the second file. 

# ## Libraries

# In[1]:

## Import Modules
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from patsy import dmatrices
from sklearn.metrics import confusion_matrix
import sklearn
from sklearn import datasets
import statsmodels.api as sm
import statsmodels.formula.api as smf
import statsmodels
import seaborn as sns


# In[2]:

## Enable inline plotting for graphics
get_ipython().magic('matplotlib inline')


# In[3]:

## Get Version information
print(sys.version)
print("Pandas version: {0}".format(pd.__version__))
print("Matplotlib version: {0}".format(matplotlib.__version__))
print("Numpy version: {0}".format(np.__version__))
print("SciKitLearn version: {0}".format(sklearn.__version__))
print("Statsmodels version: {0}".format(statsmodels.__version__))


# ## Check your working directory

# Subsequent sessions may require you to identify and update your working directory so paths correctly point at the downloaded data files. You can check your working directory like so:

# In[4]:

## Check/set your working directory
print("My working directory:\n" + os.getcwd())
# Set Working Directory (if needed)
os.chdir(r"C:\Users\evan\Dropbox\BH_Katie_Share\Goldman_Sachs")
print("My new working directory:\n" + os.getcwd())


# ## Machine Learning

# * Machine learning is the science of programming algorithms to learn from data.
# * Machine learning is focused on prediction – Predictive Modeling
# * Machine learning typically uses finite sample properties to optimize models
# * Traditional statistics focuses on process inference -statistical inference
# * Traditional statistics often use asymptotic properties to make inference
# * In practice, there is much overlap between the disciplines...

# ## Machine Learning Terminology

# * Target: what I want to predict
# * Inputs: The variables I am using to predict the target
# * Samples: The rows of the dataframe
# * Unsupervised Learning: Algorithms without a target
# * Clustering
# * Dimensionality Reduction
# * Supervised Learning: Algorithms using a target
# * Classication: Target is discrete
# * Regression: Target is continuous

# ## Variance, Bias, Over-fitting

# * Variance refers to how variables your estimates are
# * Bias refers to how accurate your estimates are
# * Think of shooting arrows at a target: Low bias means on average, you get close to the center. Low variance means your arrows are all close together
# * There is often a tradeoff between bias and variance.
# * Over-fitting our data: too many attempts at fitting leads to a great fit...but only for this data?
# 

# ## Avoiding Overfitting

# * Incorporate your topical knowledge when selecting features
# * The best models come from careful feature selection rather than automated decisions.
# * Remove redundant variables (highly correlated)
# * Censor values in your data you know to be inaccurate (Careful data cleaning)
# * Identify structure in your data and use it appropriately

# ## Cross Validation

# * Create training and test datasets
# * Independence between sets
# * Remove redundant variables (highly correlated)
# * Run this several times
# * Be wary of implausibly great results - may have overfit the data

# ## Steps to Machine Learning

# * Identify your question to be answered: classification, regression, or clustering?
# * What data is available?
# * Do you have targets (supervised) ?
# * What features make the most sense in the context of your problem?
# * Clean your data for unlikely values, examine your dataset
# * Identify models that correspond to your structural requirements
# * Unsupervised versus supervised
# * Classification or regression?
# * Distribution of the target (how many levels, what is the domain of the numbers if regression)

# ## Datasets in scikitlearn

# * Some datasets come internally with Scikit-learn
# * We can load them with datasets.load()

# In[5]:

from sklearn import datasets

## Datasets that come with SK Learn
diabetes = datasets.load_diabetes()
boston = datasets.load_boston()
iris = datasets.load_iris()
linnerud = datasets.load_linnerud()


# ## Dataset Attributes

# * The datasets have multiple attributes that can be accessed, including DESCR, data, and target.
# * The .data is the X (inputs), the .target is the Y (outcome)

# In[6]:

boston = datasets.load_boston()
print(boston.DESCR)


# In[7]:

dir(boston)


# In[8]:

boston.feature_names


# In[9]:

boston.data.shape


# In[10]:

np.set_printoptions(linewidth=100)
boston.data[0:5,:]


# In[11]:

boston.target


# ## Create a Pandas Dataframe from this Data

# Let's create a Pandas dataframe from this dataset to replicate the full process of turning a dataframe into numpy arrays.

# In[12]:

boston_df = pd.DataFrame(boston.data)


# In[13]:

boston_df.columns = boston.feature_names


# In[14]:

boston_df['median_value'] = boston.target


# In[15]:

boston_df.head()


# ## Workflow into scikit-learn

# * There are a number of possible ways to prepare data for modeling in SciKit-Learn. 
# * You must end up with a numeric ndarray of inputs (X) and a numeric ndarray matrix of the target (Y)
# * I prefer the following workflow:
# 
# * We use pandas to import and clean data
# * We use Patsy to create the X and Y ndarrays
# * Using categorical transformations (dummy coding) as needed
# * Also can generate non-linear terms including splines
# * Use scikit-learn for machine learning

# ## Use Patsy to Create the Model Matrices

# We typically start out with a pandas dataframe for manipulation purposes, then we will use this dataframe as the input to the machine learning library. I created a pandas dataframe above to replicate this process. We will use the dmatrices function from the patsy library to easily generate the design matrices for the machine learning algorithms. 

# In[16]:

## Create formula for all variables in model
vars_remove = ['median_value']
vars_left = set(boston_df.columns) - set(vars_remove)
formula = "median_value ~ " + " + ".join(vars_left)
formula


# In[17]:

## use Patsy to create model matrices
Y,X = dmatrices(formula,
                boston_df)


# In[18]:

Y


# In[19]:

X


# ## Split into Testing and Training Samples

# * The first step is to set aside a test sample of data that will allow us to examine the quality of our models. This protects against overfitting. 
# * We can use “tuple unpacking” to assign the values (very pythonic :)
# * We can assign a random seed (state) and fraction to split.

# In[20]:

## Split Data into training and sample
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(boston.data,
                                                    boston.target,
                                                    test_size=0.25,
                                                    random_state=42)


# ## Confirm the Output Dimensions

# * We can confirm the dimensions of the data are the same within test and train
# * The proportion should also be close to the test_size argument. 

# In[21]:

## Confirm dimensions
X_train.shape


# In[22]:

X_test.shape


# In[23]:

y_train.shape


# In[24]:

y_test.shape


# In[25]:

## Examine the shape of X
X_test.shape


# ## Examine the Dataset: Outcome Distribution

# First, let's examine the dataset to get a sense of what we are modeling. We will start by looking at the outcome distribution.

# In[26]:

sns.distplot(boston_df.median_value)


# This looks reasonable, with some odd outliers at the high end of the distribution. 

# Let's look at the distribution of the rest of the variables.

# In[27]:

boston_df.describe()


# ## First Model: Linear Regression

# * We will start with a basic linear model (OLS regression).
# * The flow will be similar for all other models:
# * Call and save model object with initial parameters, then call the fit() method, then call other summary methods post fit. 

# In[28]:

## import linear model
from sklearn import linear_model
## Define model parameters
clf = linear_model.LinearRegression(fit_intercept=True)
## fit model using data with .fit
clf.fit(X_train,y_train)
## Make predictions on test dataset
clf.predict(X_test)


# ## Model Summaries

# * We can extract the model coefficients with the .coef_ attribute.
# * The model goodness of fit is determined by predicting on the hold out (test) set, then scoring the predictions. 

# In[29]:

## Get coefficients
clf.coef_


# In[30]:

# The mean square error
print("Residual sum of squares for null model:",
      np.mean((np.mean(y_train) - y_train) ** 2))
print("Residual sum of squares:",
      np.mean((clf.predict(X_train) - y_train) ** 2))


# ## Model Score

# In the linear model case (and most regression), the model score is the mean squared error. 
# The best score is 1, the worst score is 0.

# In[31]:

## Change in squared error as a percent of total squared error
1 - 22.3435455512/88.681731539


# In[32]:

## Explained Variance Score
## Higher is better
clf.score(X_train,y_train)


# In[33]:

## Score this model on the testing data
clf.score(X_test,y_test)


# ## Prediction from the Model

# * We can easily predict from the model using the predict method.
# * You must supply a new X for predictions of the correct shape. 
# * Here, I simply predict base on the mean covariate values. 

# In[34]:

## Make Prediction for the average value
## Notice the reshape…
clf.predict(np.mean(X_train,0).reshape(1,13))


# We could also make predictions on the test data set...

# In[35]:

clf.predict(X_test)


# ## Penalized Linear Regression: Ridge Regression

# * Ridge regression enforces an L2 penalty (regularization of the L2-norm)
# * Parameters are shrunk towards zero
# * All parameters should be retained
# * Correlated inputs will “share” the effect size
# * Alpha is the degree of penalty

# In[36]:

## ridge regression, set alpha to 0.1
clf = linear_model.Ridge(alpha=0.1)
clf.fit(X_train,y_train)


# In[37]:

## Score this model on the training data
clf.score(X_train,y_train)


# In[38]:

## Score this model on the testing data
clf.score(X_test,y_test)


# In[39]:

# The mean square error
print("Residual mean sum of squares:",
      np.mean((clf.predict(X_test) - y_test) ** 2))


# ## Scaling / Pipeline

# * We should consider scaling when we use shrinkage methods. 
# * We can construct a pipeline to avoid having to apply the same transformation over and over again.
# * We must use the StandardScaler() function here.

# In[40]:

## ridge regression, set alpha
from sklearn import preprocessing
from sklearn.pipeline import Pipeline
clf = linear_model.Ridge(alpha=0.1)
scaler = preprocessing.StandardScaler().fit(X_train)
pipe1 = Pipeline([("scale", scaler),
                     ("ridge", clf)])
pipe1.fit(X_train,y_train)


# In[41]:

## Score on training data
pipe1.score(X_train,y_train) 


# In[42]:

## Score on testing data
pipe1.score(X_test,y_test) 


# ## Selecting Parameters via Cross Validation

# For the ridge regression, the primary parameter of interest ist alpha. We can select the shrinkage parameter (alpha) through cross-validation. The default cross validation strategy is called 'leave one out'. We can also select a specific number of folds and do k-folds cross validation. 

# In[43]:

## Select the alpha through cross validation (leave one out)
clf = linear_model.RidgeCV(alphas=[0.01, 0.5, 0.1, 0.15, 0.2, 0.5])
scaler = preprocessing.StandardScaler()
pipe2 = Pipeline([("scale", scaler),
                     ("ridge", clf)])
pipe2.fit(X_train,y_train)


# In[44]:

pipe2.named_steps['ridge'].alpha_


# In[45]:

## Examine the score of the model on training data
pipe2.score(X_train,y_train) 


# In[46]:

## Score on testing data
pipe2.score(X_test,y_test) 


# In[47]:

## Select the alpha by 10 fold cross validation
clf = linear_model.RidgeCV(alphas=[0.01, 0.05, 0.1, 0.15, 0.2, 0.5],
                          cv=10)
scaler = preprocessing.StandardScaler()
pipe3 = Pipeline([("scale", scaler),
                     ("ridge", clf)])
pipe3.fit(X_train,y_train)


# In[48]:

pipe3.named_steps['ridge'].alpha_


# In[49]:

## Examine the score of the model on training data
pipe3.score(X_train,y_train) 


# In[50]:

## Score on testing data
pipe3.score(X_test,y_test) 


# ## Alpha Selection

# In both cases, we found an alpha of 0.5 to be optimal.

# ## Penalized Linear Regression: LASSO

# * LASSO regression is also as shrinkage estimator (penalty). 
# * LASSO uses an L1 penalty, and variables can be dropped as a result of shrinkage (coefficients set to 0)
# * If there are correlated inputs, only one will dominate in the shrinkage, while the other will be set to a small coefficient (or 0)

# In[51]:

## LASSO regression
clf = linear_model.Lasso(alpha = 0.1)
clf.fit(X_train,y_train)
clf.coef_


# ## Cross Validating Alpha

# The LASSO regression also has a parameter which must be selected. Alpha is the degree of shrinkage for the penalty. We can cross validate this parameter just as we did in the ridge regression:

# In[52]:

## Select the alpha through cross validation (leave one out)
clf = linear_model.LassoCV(alphas=[0.01, 0.05, 0.1, 0.15, 0.2, 0.5])
scaler = preprocessing.StandardScaler()
pipe4 = Pipeline([("scale", scaler),
                  ("lasso", clf)])
pipe4.fit(X_train,y_train)


# In[53]:

pipe4.named_steps['lasso'].alpha_


# In[54]:

## Examine the score of the model on training data
pipe4.score(X_train,y_train) 


# In[55]:

## Score on testing data
pipe4.score(X_test,y_test) 


# In[56]:

## Select the alpha by 10 fold cross validation
clf = linear_model.LassoCV(alphas=[0.01, 0.05, 0.1, 0.15, 0.2, 0.5],
                          cv=10)
scaler = preprocessing.StandardScaler()
pipe5 = Pipeline([("scale", scaler),
                  ("lasso", clf)])
pipe5.fit(X_train,y_train)


# In[57]:

pipe5.named_steps['lasso'].alpha_


# In[58]:

## Examine the score of the model on training data
pipe5.score(X_train,y_train) 


# In[59]:

## Score on testing data
pipe5.score(X_test,y_test) 


# ## Implementing Polynomial and Interaction Terms

# * We can add polynomials as well as interactions using PolynomialFeatures. 
# * We must give the degree argument. Polynomials up to that degree will be considered, and interactions between d-1 terms.
# * This is a lot of parameters added into the model! That is why we are using LASSO to shrink some and avoid overfitting…

# In[60]:

## try multiple polynomials with a LASSO
## use pipeline for pre-processing
## Select the alpha by 10 fold cross validation
from sklearn.preprocessing import PolynomialFeatures
clf = linear_model.LassoCV(alphas=[0.1, 0.15, 0.2, 0.5],
                          cv=10)
scaler = preprocessing.StandardScaler()
poly_feat = PolynomialFeatures(degree=2,include_bias=False)
pipe6 = Pipeline([("scale", scaler),
                  ("poly",poly_feat),
                  ("lasso", clf)])
pipe6.fit(X_train,y_train)


# In[61]:

pipe6.named_steps['lasso'].alpha_


# In[62]:

## Examine the score of the model on training data
pipe6.score(X_train,y_train) 


# In[63]:

## Score on testing data
pipe6.score(X_test,y_test) 


# In[64]:

## Examine the coefficients
pipe6.named_steps['lasso'].coef_

